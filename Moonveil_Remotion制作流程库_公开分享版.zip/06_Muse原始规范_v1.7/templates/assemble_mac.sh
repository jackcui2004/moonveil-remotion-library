#!/bin/bash
# Moonveil Vox 第1集 — Mac 端总装脚本
# 用法：把本脚本和 full_audio_fixed2.m4a（修正版音轨v3）放到 full_episode_vox_v1/ 目录里（与 units/ 同级），
# 在终端 cd 到该目录后运行：bash assemble_mac.sh
set -u
cd "$(dirname "$0")"

UNITS="INTRO ANN_01 NAR_01 ANN_02 NAR_02 ANN_03 NAR_03 ANN_04 NAR_04 ANN_05 NAR_05 ANN_06 NAR_06 ANN_07 NAR_07 R1 ANN_08 NAR_08 ANN_09 NAR_09 ANN_10 NAR_10 ANN_11 NAR_11 ANN_12 NAR_12 R2 ANN_13 NAR_13 ANN_14 NAR_14 ANN_15 NAR_15 ANN_16 NAR_16 ANN_17 NAR_17 ANN_18 NAR_18 R3 ANN_19 NAR_19 ANN_20 NAR_20 EPI OUTRO"

missing=0
for u in $UNITS; do
  if [ ! -f "units/$u.mp4" ]; then echo "缺少单元: units/$u.mp4"; missing=1; fi
done
if [ "$missing" = "1" ]; then echo "有单元缺失，先补齐再总装。"; exit 1; fi
if [ ! -f "full_audio_fixed2.m4a" ]; then echo "缺少 full_audio_fixed2.m4a（修正版音轨v3），请先从云盘项目包下载到本目录。"; exit 1; fi

LIST=$(mktemp)
for u in $UNITS; do echo "file 'units/$u.mp4'" >> "$LIST"; done

echo "拼接 46 个单元..."
ffmpeg -y -v error -f concat -safe 0 -i "$LIST" -c copy _video_only.mp4 || { echo "拼接失败"; exit 1; }

DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 _video_only.mp4)
echo "纯视频时长: $DUR 秒（目标约 5929.7）"

echo "混入最终音轨（配音+垫乐+音效）..."
ffmpeg -y -v error -i _video_only.mp4 -i full_audio_fixed2.m4a -map 0:v:0 -map 1:a:0 -c copy "Moonveil_Vox完整版_Mac版.mp4" || { echo "混音失败"; exit 1; }

rm -f "$LIST" _video_only.mp4
echo "完成: Moonveil_Vox完整版_Mac版.mp4"
ls -la "Moonveil_Vox完整版_Mac版.mp4"
ffprobe -v error -show_entries format=duration -of csv=p=0 "Moonveil_Vox完整版_Mac版.mp4"
