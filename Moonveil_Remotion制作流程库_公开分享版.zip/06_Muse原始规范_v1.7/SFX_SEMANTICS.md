# Moonveil 音效语义规范（SFX_SEMANTICS）

音效库：`~/workspace/moonveil/sfx_library/`（24 个真实录音/设计 WAV、48kHz 单声道、11 类）。
**禁止程序合成的哔哔声**（用户已否决）；只许用库内真实音效。

## 1. 语义映射（一类事件永远同一种声音 — 观众要形成听觉语言）

| 画面事件 | 音效类型 | 说明 |
|---|---|---|
| 元素弹窗 / 面板出现 | popup | pop_pluck / pop_soft_thock |
| 短信 / 消息气泡到达 | message (bloop/ding) | 真录铃声 ding |
| 卡片 / 元素飞入（短） | whoosh_s | 短促空气声，**只给信息元素** |
| 大转场（章节/段落结构切换） | whoosh_l | 长空气声，用量最克制 |
| 卡片滑入 | card_slide | |
| 关系图节点 / 轻 UI 落位 | tick / click | 重节点用 tick_low (bong) |
| 选项牌 / 果断选择 | tap | |
| 金句行落下 | swell | 轻 swell 收束 |
| 月亮 / 金字标题微光点缀 | sparkle | 玻璃边沿声 |
| 书页 / 书本动作 | page_turn | |
| 打字点 / 微 UI | typing_blip | |

## 2. 铁律（2026-11-01 用户亲自定性，源于第 1 集开头返工）

1. **IP 人物叠化（换表情/换姿态）不配任何音效。** 她安静地叠化过去就对了。
2. **whoosh 是卡片/标签等信息元素飞入的声音**，不是转场万能胶；除大结构转场外不许用在人像上。
3. **密度红线**：以用户批过的 v1 开头为标尺——开头 45 秒内 whoosh 类 ≤2 下（12.4 元素拍点、38.58 结构转场）、事件总数保持稀疏；主持段每个单元只保留信息元素事件（标题卡 card_slide、标签 tick、选项 tap、气泡 ding）。
   - 反面教材：曾把人像每次叠化都配 whoosh，45 秒堆到 13 下，听感成“一直咻咻咻”，虽逐帧对齐仍判不合格——**对齐是及格线，语义与密度才是对错**。
4. **质检必查开头密度**：交付前数一遍开头 45 秒与每个主持段的事件构成，发现人像点位有声直接打回。

## 3. 构建参数（build_audio.py 现行值）

- 分级目标峰值（线性，越长压得越低）：swell 0.32、card_slide 0.22、whoosh_s 0.17、whoosh_l 0.13，其余按表内 TARGET。
- 防叠响：两事件间隔 <0.35 秒，后者增益 ×0.79。
- whoosh 锚定：按音效时长回退起点，使能量峰落在画面命中帧；其余类型落在事件帧。
- 整体位置：音效总线退到旁白之后（成品音效轨峰值约 0.36 线性 / 混音后以 −18.6 LUFS 标准为准），不许抢戏。

## 4. 授权与署名

- Kenney Interface Sounds — CC0；Robin Lamb / VCSL — CC0。
- Little Robot Sound Factory — **CC-BY 3.0**：每条视频说明必须带署名行：
  `UI sounds by Little Robot Sound Factory — www.littlerobotsoundfactory.com`
