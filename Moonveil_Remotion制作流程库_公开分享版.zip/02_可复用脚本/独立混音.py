"""Mix a complete narration with sparse real SFX; measure the encoded output."""
import argparse,json,pathlib,subprocess,tempfile

def run(args,**kw):return subprocess.run(args,check=True,**kw)
def seconds(p):return float(run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(p)],capture_output=True,text=True).stdout)
def loudness(p):
 r=run(['ffmpeg','-hide_banner','-i',str(p),'-af','loudnorm=I=-18.6:TP=-0.5:LRA=11:print_format=json','-f','null','-'],capture_output=True,text=True)
 return json.JSONDecoder().raw_decode(r.stderr[r.stderr.rfind('{'):])[0]
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--voice',required=True);ap.add_argument('--events');ap.add_argument('--output',required=True);ap.add_argument('--覆盖',action='store_true',dest='overwrite');a=ap.parse_args()
 voice=pathlib.Path(a.voice).expanduser().resolve();out=pathlib.Path(a.output).expanduser().resolve()
 if out.suffix.lower()!='.m4a':raise ValueError('输出须为.m4a')
 if out==voice:raise ValueError('输出不能覆盖原旁白')
 if out.exists() and not a.overwrite:raise FileExistsError('已有输出；显式加--覆盖才替换')
 ep=pathlib.Path(a.events).expanduser().resolve() if a.events else None
 events=json.loads(ep.read_text()) if ep else []
 if isinstance(events,dict):events=events['events']
 if not isinstance(events,list):raise ValueError('事件应为数组或含events数组的对象')
 duration=seconds(voice);cmd=['ffmpeg','-y','-v','error','-i',str(voice)];filters=['[0:a]aformat=sample_rates=48000:channel_layouts=mono[v]'];labels=['[v]'];used=[]
 for i,e in enumerate(events):
  at=float(e['at']);gain=float(e['gain']);asset=pathlib.Path(e['asset']).expanduser()
  if not asset.is_absolute():asset=(ep.parent/asset).resolve()
  if at<0 or gain<0 or not asset.is_file():raise ValueError(f'无效事件{i+1}')
  if at+seconds(asset)>duration+.05:raise ValueError(f'事件{i+1}尾部超出完整旁白，先修正时间')
  cmd+=['-i',str(asset)];filters.append(f'[{i+1}:a]aformat=sample_rates=48000:channel_layouts=mono,volume={gain},adelay={round(at*1000)}:all=1[s{i}]');labels.append(f'[s{i}]');used.append({**e,'asset':str(asset)})
 filters.append(''.join(labels)+f'amix=inputs={len(labels)}:duration=first:normalize=0,alimiter=limit=0.94:level=false:latency=true[m]')
 out.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='moonveil_mix_',dir=out.parent) as t:
  raw=pathlib.Path(t)/'mix.wav';partial=pathlib.Path(t)/'master.m4a'
  run(cmd+['-filter_complex',';'.join(filters),'-map','[m]','-c:a','pcm_s16le',str(raw)])
  m=loudness(raw)
  if m['input_i']=='-inf':raise ValueError('旁白/混音是静音')
  filt='loudnorm=I=-18.6:TP=-0.5:LRA=11:measured_I='+m['input_i']+':measured_TP='+m['input_tp']+':measured_LRA='+m['input_lra']+':measured_thresh='+m['input_thresh']+':offset='+m['target_offset']+':linear=true'
  run(['ffmpeg','-y','-v','error','-i',str(raw),'-af',filt,'-ar','48000','-ac','1','-c:a','aac','-b:a','160k','-movflags','+faststart',str(partial)])
  measured=loudness(partial);actual=seconds(partial)
  if abs(actual-duration)>.12:raise ValueError('终混与原旁白时长不符')
  partial.replace(out)
 report={'voice':str(voice),'events':used,'source_seconds':duration,'output_seconds':actual,'first_pass':m,'encoded_output_measurement':measured,'targets':{'I':-18.6,'TP':-.5,'LRA':11},'loudness_within_0_3_LU':abs(float(measured['input_i'])+18.6)<=.3,'note':'编码后的input_i/input_tp才是实际测量；TP可能因AAC略变，需按报告判断'}
 out.with_suffix('.混音报告.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'output':str(out),'seconds':actual,'LUFS':measured['input_i'],'true_peak':measured['input_tp']},ensure_ascii=False))
if __name__=='__main__':main()
