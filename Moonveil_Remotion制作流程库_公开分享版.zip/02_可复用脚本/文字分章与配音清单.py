"""Create explicit chapter/TTS inputs without generating speech or changing prose."""
import argparse, hashlib, json, pathlib, re

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--input',required=True);ap.add_argument('--output',required=True)
 ap.add_argument('--voice',default='en-US-AvaMultilingualNeural');ap.add_argument('--max-chars',type=int,default=1200)
 ap.add_argument('--覆盖',action='store_true',dest='overwrite');a=ap.parse_args()
 src=pathlib.Path(a.input).expanduser().resolve();out=pathlib.Path(a.output).expanduser().resolve()
 if a.max_chars<100:raise ValueError('max-chars需至少100')
 text=src.read_text(encoding='utf-8-sig')
 if src.suffix.lower()=='.json':
  chapters=json.loads(text)
  if not isinstance(chapters,list):raise ValueError('JSON应为章节数组')
 else:
  pat=re.compile(r'^(?:Chapter\s+(?:\d+|[A-Za-z]+)\s*[:：.\-—].*|第[一二三四五六七八九十百零〇\d]+章[^\n]*)$',re.M|re.I)
  hits=list(pat.finditer(text))
  if not hits:raise ValueError('未发现明确章节标题，请提供chapter/title/body的JSON数组')
  if text[:hits[0].start()].strip():raise ValueError('首章之前有内容，请明确放入章节JSON，避免漏掉前言')
  chapters=[{'chapter':i+1,'title':h.group().strip(),'body':text[h.end():hits[i+1].start() if i+1<len(hits) else len(text)].strip()} for i,h in enumerate(hits)]
 if not chapters:raise ValueError('没有章节')
 targets=['chapters_source.json','tts_manifest.json','文本准备报告.json','source_story.txt' if src.suffix.lower()!='.json' else 'source_chapters_input.json']
 if not a.overwrite and any((out/n).exists() for n in targets):raise FileExistsError('输出已存在；检查后再显式加--覆盖')
 rows=[];body_count=0;ids=[]
 for i,c in enumerate(chapters):
  number=c.get('chapter');title=c.get('title');body=c.get('body')
  if not isinstance(number,int) or number<1 or not isinstance(title,str) or not title.strip() or not isinstance(body,str) or not body.strip():raise ValueError(f'第{i+1}项缺少有效chapter/title/body')
  if ids and number<=ids[-1]:raise ValueError('章节编号必须递增且唯一')
  ids.append(number);c['words']=len(body.split());body_count+=c['words'];pieces=[]
  for para in re.split(r'\n\s*\n',body.strip()):
   para=para.strip()
   if len(para)<=a.max_chars:pieces.append(para);continue
   # A lossless greedy split: prefer a sentence or whitespace boundary.
   while len(para)>a.max_chars:
    window=para[:a.max_chars+1];boundaries=[m.end() for m in re.finditer(r'[.!?]["\u201d\u2019\']?\s+',window)]
    cut=boundaries[-1] if boundaries else window.rfind(' ')
    if cut<1:raise ValueError('超长无空格文本，请提供更合适的分段')
    pieces.append(para[:cut].strip());para=para[cut:].strip()
   if para:pieces.append(para)
  if re.sub(r'\s+','',body)!=re.sub(r'\s+','',' '.join(pieces)):raise ValueError('正文完整性检查失败')
  all_parts=[('title',re.sub(r'[:：]','.',title,count=1))]+[('body',p) for p in pieces]
  for j,(kind,part) in enumerate(all_parts):
   rid=f'CH{number:02d}_P{j:03d}';digest=hashlib.sha256((a.voice+'\0'+part).encode()).hexdigest()[:12]
   rows.append({'id':rid,'cache_id':rid+'_'+digest,'chapter':number,'kind':kind,'text':part,'voice':a.voice,'words_expected':len(part.split())})
 out.mkdir(parents=True,exist_ok=True)
 for name in ['audio/tts_cache','src','public/images','public/videos','public/sfx','reports','scripts']:(out/name).mkdir(parents=True,exist_ok=True)
 (out/targets[-1]).write_text(text,encoding='utf-8')
 for name,data in [('chapters_source.json',chapters),('tts_manifest.json',rows),('文本准备报告.json',{'输入':str(src),'章节数':len(chapters),'正文词数':body_count,'配音段数':len(rows),'声线':a.voice,'正文去空白逐字完整性':'通过','状态':'只准备输入，未配音'})]:
  (out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'输出':str(out),'章节':len(chapters),'正文词':body_count,'配音段':len(rows)},ensure_ascii=False))
if __name__=='__main__':main()
