# AAC-LC 音轨交付修复

2026-11-13：启动高速渲染和节省磁盘总装均使用同一AAC音轨门禁。MP3等转AAC-LC；兼容AAC可复制。检查通过才发布成片，不再用任意来源音频包哈希一致代替播放兼容验收。

共享模块：高速渲染核心/scripts/audio_delivery.py。文档与单独运行入口：workflow/README.md、workflow/tools/audio_delivery.py。历史目录仅用于参考，后续项目使用本目录当前队列。
