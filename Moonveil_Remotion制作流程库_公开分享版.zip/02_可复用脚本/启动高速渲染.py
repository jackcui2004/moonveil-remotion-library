"""Prepare by default; --执行 explicitly runs the local queue and progress page."""
import argparse,json,pathlib,subprocess,sys,os

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--project',required=True);ap.add_argument('--timeline');ap.add_argument('--audio');ap.add_argument('--title',default='Moonveil');ap.add_argument('--jobs',type=int,default=6);ap.add_argument('--port',type=int,default=3033);ap.add_argument('--执行',action='store_true',dest='execute');a=ap.parse_args()
 if not 1<=a.jobs<=8:raise ValueError('独立切片数范围1–8')
 here=pathlib.Path(__file__).resolve().parent;core=here/'高速渲染核心/scripts';root=pathlib.Path(a.project).expanduser().resolve()
 cmd=[sys.executable,str(core/'render.py'),'prepare',str(root),'--jobs',str(a.jobs),'--title',a.title]
 if a.timeline:cmd+=['--timeline',str(pathlib.Path(a.timeline).expanduser().resolve())]
 if a.audio:cmd+=['--audio',str(pathlib.Path(a.audio).expanduser().resolve())]
 r=subprocess.run(cmd,capture_output=True,text=True,check=True);p=json.loads(r.stdout);plan=p['plan'];print(r.stdout.strip(),flush=True)
 if abs(float(p.get('audio_delta',0)))>1:raise ValueError('完整混音与画面时长差超过1秒，请先核对时间轴和音轨版本')
 if not a.execute:print('仅已准备计划；加--执行才会开始渲染。',flush=True);return
 state=pathlib.Path(plan).parent/'state.json'
 if state.exists():
  d=json.loads(state.read_text());pid=d.get('pid')
  if pid:
   check=subprocess.run(['ps','-p',str(pid),'-o','args='],capture_output=True,text=True).stdout
   if plan in check:print('同一计划已运行，请复用现有进度页。',flush=True);return
 log=root/'dashboard_library.log'
 with log.open('a') as f:
  subprocess.Popen([sys.executable,str(core/'dashboard.py'),plan,'--port',str(a.port)],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print('实时看板地址见 '+str(log)+'；端口冲突会自动递增。',flush=True)
 cmd=[sys.executable,str(here/'节省磁盘总装.py'),plan]
 if sys.platform=='darwin':cmd=['caffeinate','-i']+cmd
 print('开始渲染；日志 '+str(root/'render_library.log'),flush=True)
 with (root/'render_library.log').open('a') as f:
  code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
 if code:raise SystemExit(code)
 print('队列已结束，请读取state与verification确认最终状态。',flush=True)
if __name__=='__main__':main()
