# 05 Remotion编排与运镜

工程入口：src/index.ts → Root.tsx注册composition → 对应画面组件 → timeline驱动时间。

两条已实际使用的路线：EP3的Vox宽板信息系统；EP4的电影全幅+私人日记。源码分别在04和05。不要把同样叫camera的数组在两个工程里当成同一格式。

EP3 useCamera关键帧：[秒,缩放,中心x,中心y]；在1280×720板面内计算translate(640-cx*s,360-cy*s) scale(s)，再整板放大到1920×1080。长静止段保持中心，交接前短窗口移动。字幕、章节卡等屏幕元素不要跟着大画布漂走。

EP4 timeline：fps/width/height/audio/units；每unit包含id、全片start/end、frames、局部scenes、captions。scene含start/end、asset、mode、title、quote；字幕含实际words边界。章节id与Root注册id必须一致。只有10章注册不代表音频也是全集。

director_plan.py是177个手选剧情锚点，cue匹配实际原文，再落到语音词时间；build_full_timeline.py将长段拆到约21秒并在词边界附近交接。这会复用同图不同布局，是素材少时的案例策略，不是未来减少重复的目标方案。

视频：先绝对定位容器，再Sequence；渲染用OffthreadVideo，预览用Html5Video；底部有同源海报，片段播放按实际源时长。EP4视频只播10秒一次，后接下一画面；相邻画面约0.22秒叠化，旧视频退场使用末端海报，避免跳回中间帧。

有声预览：EP4 Studio用完整Html5Audio并按章节startFrom/endAt定位。中间渲染关闭组件音轨是设计，最终总装另合完整master。

运镜选型与限制详见04。Vox信息动画要有剧情含义；不因“有这个组件”就在每章硬塞地图。
