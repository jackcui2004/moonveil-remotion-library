"""Rebuild the local reading/audio page and a file checksum inventory."""
from pathlib import Path
import html,json,hashlib,csv,urllib.parse,re

R=Path(__file__).resolve().parents[1]
E=html.escape
def href(p):return urllib.parse.quote(str(p),safe='/')
def doc_html(text):
 blocks=[];para=[];code=[]
 def flush():
  if para:blocks.append('<p>'+E('\n'.join(para))+'</p>');para.clear()
  if code:blocks.append('<pre>'+E('\n'.join(code))+'</pre>');code.clear()
 for line in text.splitlines()+['']:
  if line.startswith('    '):
   if para:flush()
   code.append(line[4:]);continue
  if code:flush()
  if not line.strip():flush();continue
  if line.startswith('#'):
   flush();n=min(4,len(line)-len(line.lstrip('#')));blocks.append(f'<h{n+1}>'+E(line.lstrip('#').strip())+f'</h{n+1}>')
  elif line.startswith('- '):flush();blocks.append('<p class="bullet">• '+E(line[2:])+'</p>')
  else:para.append(line)
 return ''.join(blocks)
sounds=json.loads((R/'03_音效库/音效索引.json').read_text());refs=json.loads((R/'04_Vox风格与运镜/公开参考目录.json').read_text())
registered={('03_音效库/'+s['文件']) for s in sounds}
extras=[p for base in ['03_音效库','08_以后收集放这里'] for p in (R/base).rglob('*') if p.is_file() and p.suffix.lower() in ['.wav','.mp3','.m4a'] and str(p.relative_to(R)) not in registered]
docs=[]
for base in ['00_先看这里','01_逐步制作说明','02_可复用脚本','03_音效库','04_Vox风格与运镜','05_EP4完整案例','06_Muse原始规范_v1.7','07_历史脚本存档_EP1_EP3','08_以后收集放这里']:
 for p in sorted((R/base).glob('*.md')):
  # Raw large novel/storyboard is available from the file index, not repeated in the reading page.
  if p.name=='云端v17原分镜_历史参考.md':continue
  docs.append(p)
nav=[];sections=[]
for i,p in enumerate(docs):
 ident='doc'+str(i);label=p.stem
 nav.append('<a href="#'+ident+'">'+E(label)+'</a>')
 sections.append('<details class="doc" id="'+ident+'"><summary>'+E(label)+' <small>'+E(p.parent.name)+'</small></summary><article>'+doc_html(p.read_text())+'<p><a href="'+href(p.relative_to(R))+'">查看原文文件 ↗</a></p></article></details>')
cards=[]
for i,s in enumerate(sounds):
 path='03_音效库/'+s['文件'];bad='停用' in s['状态'];status='慎用 / 默认停用' if bad else ('提取参考' if '提取' in s['名称'] else '轻量备选')
 cards.append(f'<div class="sound"><span class="tag {"warn" if bad else ""}">{E(status)}</span><h3>{E(s["名称"])}</h3><p>{E(s["用途"])} · {s["时长秒"]}秒</p><audio id="sound{i}" controls preload="none" aria-label="{E(s["名称"])}"><source src="{href(path)}" type="audio/wav"></audio><p class="note">{E(s["状态"])}<br>{E(s["备注"])}</p><details><summary>来源与文件</summary><p class="note">{E(s["来源"])}<br>{E(s["授权状态"])}</p><a href="{href(path)}">原音频文件</a></details></div>')
for p in extras:cards.append('<div class="sound"><span class="tag warn">新收集 · 未登记待备注</span><h3>'+E(p.stem)+'</h3><audio controls preload="none" src="'+href(p.relative_to(R))+'"></audio><p>请按收集模板补用途、来源、授权和试听状态。</p></div>')
ref_html=''.join('<a class="ref" href="'+E(s['链接'],quote=True)+'" target="_blank" rel="noopener"><strong>'+E(s['名称'])+' ↗</strong><span>'+E(s['说明'])+'</span></a>' for s in refs)
skip={'开始阅读.html','文件总索引.json','文件树.txt','.DS_Store'}
files=[p for p in sorted(R.rglob('*')) if p.is_file() and p.name not in skip and '__pycache__' not in p.parts]
inventory=[{'文件':str(p.relative_to(R)),'字节':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(R/'文件总索引.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2))
(R/'文件树.txt').write_text('\n'.join(i['文件'] for i in inventory)+'\n')
file_links=''.join('<li><a href="'+href(i['文件'])+'">'+E(i['文件'])+'</a><span>'+str(round(i['字节']/1024,1))+' KB</span></li>' for i in inventory)
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Moonveil · Remotion制作流程库</title><style>
:root{--bg:#f6f3ed;--paper:#fffdf8;--ink:#23312c;--muted:#687269;--line:#d9ded3;--green:#315c4a;--gold:#a77c33}*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:24px}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.8 -apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif}a{color:var(--green);text-decoration:none}a:hover{text-decoration:underline}header{padding:52px max(28px,calc((100% - 1220px)/2));background:#203e32;color:#f7f4e9}header p{max-width:800px;color:#d1dfd5}h1{font-size:36px;letter-spacing:-1px;margin:12px 0}h2{font-size:25px;margin:0 0 16px}h3{font-size:18px}h4,h5{font-size:17px}small,.note{font-size:13px;color:var(--muted)}.eyebrow{font-size:12px;letter-spacing:3px;color:#e5c787}.stats{display:flex;gap:12px;flex-wrap:wrap;margin-top:24px}.stats span{border:1px solid #577566;border-radius:8px;padding:7px 13px}main{max-width:1280px;margin:auto;padding:32px 28px;display:grid;grid-template-columns:235px minmax(0,1fr);gap:30px}aside{position:sticky;top:24px;align-self:start;max-height:92vh;overflow:auto}aside a{display:block;font-size:13px;padding:5px 0}aside strong{display:block;margin:14px 0 5px}.content>section{margin-bottom:40px}.intro,.doc,.sound,.ref,.folder{background:var(--paper);border:1px solid var(--line);border-radius:12px}.intro{padding:24px}.intro p{margin:7px 0}.folders{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.folder{padding:16px}.folder b{display:block}.folder span{font-size:13px;color:var(--muted)}.doc{margin:10px 0;scroll-margin-top:22px}.doc>summary{padding:17px 20px;cursor:pointer;font-weight:600}.doc small{font-weight:400;display:block;margin-left:17px}.doc article{padding:0 24px 20px}.doc p{white-space:pre-wrap;overflow-wrap:anywhere}.doc article h2:first-child{font-size:23px}.bullet{margin:6px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#eaece4;border-radius:7px;padding:16px;font-size:13px}.sounds{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.sound{padding:20px;min-width:0}.sound h3{margin:10px 0 8px}.sound p{margin:9px 0}audio{width:100%;height:40px;margin:10px 0}.tag{font-size:11px;padding:3px 8px;border-radius:5px;color:#315c4a;background:#e3eee3}.tag.warn{color:#875a28;background:#f3e7d0}.ref{display:block;padding:17px 20px;margin:10px 0}.ref strong,.ref span{display:block}.ref span{font-size:13px;color:var(--muted);margin-top:4px}.files{padding:0;list-style:none}.files li{border-bottom:1px solid var(--line);padding:7px 0;font-size:12px;overflow-wrap:anywhere}.files span{color:var(--muted);margin-left:12px}.qa{width:100%;border-radius:10px}footer{font-size:12px;color:var(--muted);margin:32px 0}.path{overflow-wrap:anywhere;font-size:12px}@media(max-width:850px){main{display:block}aside{position:static;max-height:230px;margin-bottom:25px}.sounds,.folders{grid-template-columns:1fr}h1{font-size:28px}header{padding:32px 24px}}
</style><header><div class="eyebrow">MOONVEIL · PRODUCTION LIBRARY</div><h1>Remotion 制作流程库</h1><p>从文章、分镜与配图，到完整配音、Vox编排、音效终混、高速渲染和交付。按步骤阅读，也可以直接试听音效、查看源码。</p><div class="stats"><span>9个制作步骤</span><span>8条已登记音效</span><span>EP3 + EP4 实战源码</span><span>新参考持续收集</span></div></header><main><aside><strong>快速入口</strong><a href="#overview">项目目录</a><a href="#sound-library">音效试听</a><a href="#vox-references">Vox公开视频</a><a href="#file-index">全部文件与脚本</a><strong>逐步说明与备注</strong>__NAV__</aside><div class="content"><section id="overview"><div class="intro"><h2>先看这里</h2><p>这是公开流程资料库。包含制作步骤、代码参考和音效试听；私人小说全文、完整字幕、媒体工程和本机记录不在公开版中。</p><p><strong>已用于成片 / 新增基础验证 / 只读参考 / 待实现</strong> 分开标注。dong默认停用，人物叠化静音。</p><p class="path">项目路径：__ROOT__</p></div><h2 style="margin-top:28px">目录怎么用</h2><div class="folders">__FOLDERS__</div></section><section id="sound-library"><h2>音效库 · 点击试听</h2><p>轻量备选也不默认铺满。提取参考和原始独立音效分开，来源与授权不清楚就如实注明。</p><div class="sounds">__SOUNDS__</div></section><section id="vox-references"><h2>Vox · 公开视频与代码参考</h2><p>这些参考已分类，不等于全部已安装或已接入Remotion。</p>__REFS__</section><section><h2>流程、脚本细节与使用说明</h2><p>点击展开。已有完整工程可以从编排、终混或渲染阶段接续。</p>__DOCS__</section><section id="file-index"><h2>全部文件与脚本</h2><p>文件索引带SHA256；原样快照另有来源记录。以下入口用于查看文件，不会自动执行脚本。</p><ul class="files">__FILES__</ul></section><footer>建立于2026-11-03。新增资料先放“08_以后收集放这里”，补备注后运行“09_维护工具/更新目录.py”。</footer></div></main><script>
document.querySelectorAll('audio').forEach(a=>a.addEventListener('play',()=>document.querySelectorAll('audio').forEach(b=>{if(a!==b)b.pause()})));
function expandAnchor(){let el=document.getElementById(location.hash.slice(1));if(el&&el.tagName==='DETAILS')el.open=true}window.addEventListener('hashchange',expandAnchor);expandAnchor();
</script></html>'''
folders=[('00 先看这里','当前偏好与验证状态'),('01 逐步制作说明','从文章到交付，9步完整说明'),('02 可复用脚本','新集输入、终混、渲染与进度'),('03 音效库','中文名、试听、用途与来源'),('04 Vox风格与运镜','现有组件、扩展与公开视频'),('05 EP4完整案例','本次成片的真实源码与记录'),('06 Muse原规范','v1.7原文与当前差异'),('07 历史脚本','保留迭代过程，不作默认入口'),('08 以后收集','新资料和待验证脚本放这里'),('09 维护工具','重建阅读页和文件目录')]
for k,v in {'__NAV__':''.join(nav),'__ROOT__':E('Moonveil · 公开分享版'),'__FOLDERS__':''.join('<div class="folder"><b>'+E(a)+'</b><span>'+E(b)+'</span></div>' for a,b in folders),'__SOUNDS__':''.join(cards),'__REFS__':ref_html,'__DOCS__':''.join(sections),'__FILES__':file_links}.items():page=page.replace(k,v)
(R/'index.html').write_text(page,encoding='utf-8')
(R/'开始阅读.html').write_text(page,encoding='utf-8')
print(json.dumps({'文件':len(inventory),'音效':len(sounds),'新收集未登记音频':len(extras),'说明文档':len(docs),'总字节':sum(i['字节'] for i in inventory),'入口':str(R/'开始阅读.html')},ensure_ascii=False))
