import React from "react";
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  interpolate,
  Loop,
  OffthreadVideo,
  Sequence,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import vox from "./vox_timeline.json";

const IVORY = "#efe6d0";
const GOLD = "#d9a441";
const CRIMSON = "#a41623";
const CRIMSON_BRIGHT = "#c1272d";
const INK = "#14100c";
const DISPLAY = '"Arial Narrow","Liberation Sans Narrow","HelveticaNeue-CondensedBold",sans-serif';
const SERIF = 'Georgia,"Liberation Serif",serif';
const SANS = '"Helvetica Neue",Arial,"Liberation Sans",sans-serif';
const FPS = 30;
const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

type Unit = (typeof vox.units)[number];

function usePop(atSec: number) {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({
    frame: frame - Math.round(atSec * FPS),
    fps,
    config: { damping: 13, stiffness: 130, mass: 0.85 },
  });
}

function fadeT(t: number, t0: number, t1: number, out0?: number, out1?: number) {
  let v = interpolate(t, [t0, t1], [0, 1], clamp);
  if (out0 !== undefined && out1 !== undefined) {
    v *= interpolate(t, [out0, out1], [1, 0], clamp);
  }
  return v;
}

// ---------- photo panel on the board ----------
const Panel: React.FC<{
  src: string; x: number; y: number; w: number; rot: number;
  enterAt: number; exitAt: number; from: "left" | "right"; z: number;
  imgPos?: string; videoSrc?: string; videoDur?: number; hOverride?: number; shakeAt?: number; children?: React.ReactNode;
}> = ({ src, x, y, w, rot, enterAt, exitAt, from, z, imgPos, videoSrc, videoDur, hOverride, shakeAt, children }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = usePop(enterAt);
  const h = hOverride ?? (w * 9) / 16;
  const dir = from === "left" ? -1 : 1;
  let opacity = Math.min(1, p * 1.6);
  let scale = 0.9 + 0.1 * p;
  let tx = dir * (1 - p) * 150;
  let ty = (1 - p) * 24;
  if (shakeAt !== undefined && t >= shakeAt && t <= shakeAt + 0.55) {
    tx += Math.sin((t - shakeAt) * 55) * 7 * Math.exp(-(t - shakeAt) * 7);
  }
  const ex = interpolate(t, [exitAt - 0.5, exitAt], [0, 1], clamp);
  opacity *= 1 - ex;
  scale *= 1 - 0.15 * ex;
  ty += ex * 26;
  if (opacity <= 0.01 || t < enterAt - 0.1) return null;
  return (
    <div style={{
      position: "absolute", left: x, top: y, width: w, height: h, zIndex: z,
      opacity, transform: `translate(${tx}px, ${ty}px) rotate(${rot + (1 - p) * dir * 3}deg) scale(${scale})`,
      transformOrigin: "50% 60%", filter: "drop-shadow(0 24px 28px rgba(0,0,0,0.55))",
    }}>
      <div style={{ position: "relative", width: "100%", height: "100%", background: IVORY, padding: 9, boxSizing: "border-box" }}>
        <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden" }}>
          <Img src={staticFile(src)} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: imgPos ?? "50% 50%" }} />
          {videoSrc && t >= enterAt - 0.1 && (
            // The WHOLE clip plays inside the frame for the panel's entire life,
            // looping natively — never cut off, never dissolving back to a still.
            <Sequence from={Math.round(enterAt * FPS)} durationInFrames={Math.round((exitAt - enterAt) * FPS)} layout="none">
              <div style={{ position: "absolute", inset: 0 }}>
                <Loop durationInFrames={Math.max(1, Math.round((videoDur ?? 10) * FPS))}>
                  <OffthreadVideo src={staticFile(videoSrc)} muted
                    style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: imgPos ?? "50% 50%" }} />
                </Loop>
              </div>
            </Sequence>
          )}
          {children}
        </div>
      </div>
      <div style={{ position: "absolute", top: -13, left: 26, width: 92, height: 26, background: "rgba(217,164,65,0.5)", transform: "rotate(-5deg)", borderLeft: "1px dashed rgba(0,0,0,0.25)", borderRight: "1px dashed rgba(0,0,0,0.25)" }} />
      <div style={{ position: "absolute", top: -13, right: 26, width: 92, height: 26, background: "rgba(217,164,65,0.42)", transform: "rotate(4deg)", borderLeft: "1px dashed rgba(0,0,0,0.25)", borderRight: "1px dashed rgba(0,0,0,0.25)" }} />
    </div>
  );
};

// ---------- stamp ----------
const Stamp: React.FC<{ x: number; y: number; text: string; at: number; outAt: number; size?: number }> = ({ x, y, text, at, outAt, size = 30 }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = usePop(at);
  let opacity = Math.min(1, p * 2);
  opacity *= interpolate(t, [outAt - 0.7, outAt], [1, 0], clamp);
  if (opacity <= 0.01 || t < at - 0.05) return null;
  return (
    <div style={{
      position: "absolute", left: x, top: y, zIndex: 45, opacity,
      transform: `rotate(-8deg) scale(${2.3 - 1.3 * p})`,
      border: `3px solid ${CRIMSON_BRIGHT}`, color: CRIMSON_BRIGHT,
      fontFamily: DISPLAY, fontWeight: 800, fontSize: size, letterSpacing: 4,
      padding: "5px 14px 7px", borderRadius: 4, textTransform: "uppercase",
      background: "rgba(20,16,12,0.25)", boxShadow: "inset 0 0 12px rgba(164,22,35,0.35)",
      whiteSpace: "nowrap",
    }}>{text}</div>
  );
};

// ---------- tag chip ----------
const Tag: React.FC<{ x: number; y: number; text: string; at: number; outAt: number }> = ({ x, y, text, at, outAt }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = usePop(at);
  let opacity = Math.min(1, p * 1.8);
  opacity *= interpolate(t, [outAt - 0.7, outAt], [1, 0], clamp);
  if (p <= 0.01 || opacity <= 0.01) return null;
  return (
    <div style={{
      position: "absolute", left: x, top: y, zIndex: 40, opacity,
      transform: `scale(${0.55 + 0.45 * p})`, transformOrigin: "0% 50%",
      background: "rgba(16,12,9,0.92)", borderLeft: `5px solid ${GOLD}`, color: IVORY,
      fontFamily: DISPLAY, fontWeight: 700, fontSize: 19, letterSpacing: 2.2,
      padding: "7px 13px 8px", whiteSpace: "nowrap", boxShadow: "0 8px 18px rgba(0,0,0,0.5)",
    }}>{text}</div>
  );
};

// ---------- hand-drawn ellipse ----------
const DrawEllipse: React.FC<{ cx: number; cy: number; rx: number; ry: number; at: number; end: number }> = ({ cx, cy, rx, ry, at, end }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const prog = interpolate(t, [at, at + 0.8], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
  const op = fadeT(t, at, at + 0.2, end - 0.3, end);
  if (prog <= 0 || op <= 0) return null;
  return (
    <ellipse cx={cx} cy={cy} rx={rx} ry={ry} transform={`rotate(-4 ${cx} ${cy})`}
      fill="none" stroke={CRIMSON_BRIGHT} strokeWidth={5} strokeLinecap="round"
      pathLength={100} strokeDasharray={100} strokeDashoffset={100 * (1 - prog)} opacity={0.92 * op} />
  );
};

// ---------- kinetic captions (word-by-word, keys in gold) ----------
const norm = (w: string) => w.toLowerCase().replace(/[^a-z0-9']/g, "");
const Captions: React.FC<{ unit: Unit }> = ({ unit }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const s = unit.captions.find((x) => t >= x.start - 0.12 && t <= x.end + 0.05);
  if (!s) return null;
  const words = s.text.split(" ");
  const weights = words.map((w) => [...w].length + 1);
  const total = weights.reduce((a, b) => a + b, 0);
  const elapsed = Math.max(0, t - s.start);
  const dur = s.end - s.start;
  let acc = 0;
  const spans = words.map((w, i) => {
    const wStart = (acc / total) * dur;
    acc += weights[i];
    const wEnd = (acc / total) * dur;
    const current = elapsed >= wStart && elapsed < wEnd;
    const isKey = s.keys.includes(norm(w));
    return (
      <span key={i} style={{
        color: current ? "#fff" : isKey ? GOLD : IVORY,
        background: current ? CRIMSON : "transparent",
        borderRadius: 5, padding: "0 5px", margin: "0 -1px",
        fontWeight: isKey || current ? 800 : 600,
      }}>{w} </span>
    );
  });
  return (
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 24, display: "flex", justifyContent: "center", zIndex: 90 }}>
      <div style={{
        maxWidth: 1000, textAlign: "center", background: "rgba(8,6,4,0.62)",
        borderRadius: 12, padding: "10px 22px 12px", fontFamily: SANS,
        fontSize: 29, lineHeight: 1.38, letterSpacing: 0.2,
      }}>{spans}</div>
    </div>
  );
};

// ---------- note card ----------
const NoteCard: React.FC<{ card: Unit["notecards"][number] }> = ({ card }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = usePop(card.start);
  const exitP = interpolate(t, [card.end - 0.5, card.end], [0, 1], clamp);
  if (p <= 0.01 || exitP >= 1) return null;
  const x = card.x ?? (card.side === "R" ? 700 : 110);
  return (
    <div style={{
      position: "absolute", left: x, top: card.y ?? 330, width: 452, zIndex: 25,
      opacity: Math.min(1, p * 1.6) * (1 - exitP),
      transform: `translateY(${(1 - p) * 70 + exitP * 44}px) rotate(${-1.6 + (1 - p) * 2}deg) scale(${0.92 + 0.08 * p})`,
      background: IVORY, color: "#241c12", padding: "18px 22px 16px",
      boxShadow: "0 22px 34px rgba(0,0,0,0.55)", fontFamily: SANS,
    }}>
      <div style={{ fontFamily: DISPLAY, fontWeight: 800, fontSize: 17, letterSpacing: 3, color: CRIMSON, marginBottom: 9 }}>
        {card.title}
      </div>
      {card.items.map((it) => {
        const ip = interpolate(t, [it.at, it.at + 0.45], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
        return (
          <div key={it.text} style={{ position: "relative", fontSize: 22.5, fontWeight: 600, lineHeight: 1.5, opacity: ip, transform: `translateX(${(1 - ip) * 14}px)` }}>
            <span style={{ position: "absolute", left: -2, top: "54%", height: 13, width: `${ip * 100}%`, background: "rgba(193,39,45,0.35)", zIndex: 0 }} />
            <span style={{ position: "relative", zIndex: 1 }}>— {it.text}</span>
          </div>
        );
      })}
    </div>
  );
};

// ---------- kinetic big-type slam ----------
const Slam: React.FC<{ slam: Unit["slams"][number] }> = ({ slam }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = usePop(slam.at);
  const out = interpolate(t, [slam.at + slam.dur - 0.8, slam.at + slam.dur], [1, 0], clamp);
  if (p <= 0.01 || out <= 0.01) return null;
  const subOp = fadeT(t, slam.at + 0.8, slam.at + 1.5) * out;
  const crossP = slam.cross != null
    ? interpolate(t, [slam.cross, slam.cross + 0.55], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) })
    : 0;
  return (
    <div style={{ position: "absolute", left: slam.x ?? 120, top: slam.y ?? 218, width: 1040, zIndex: 55, opacity: out * Math.min(1, p * 1.7) }}>
      <div style={{
        fontFamily: DISPLAY, fontWeight: 900, fontSize: 150, lineHeight: 0.95, letterSpacing: 1,
        transform: `scale(${1.65 - 0.65 * p})`, transformOrigin: "0% 50%", whiteSpace: "nowrap",
      }}>
        <span style={{ color: slam.cross != null ? CRIMSON_BRIGHT : GOLD }}>{slam.big.split(" ")[0]}</span>{" "}
        <span style={{ color: IVORY }}>{slam.big.split(" ").slice(1).join(" ")}</span>
      </div>
      {slam.cross != null && crossP > 0 && (
        <svg style={{ position: "absolute", left: -8, top: 2, overflow: "visible" }} width={720} height={150} viewBox="0 0 720 150">
          <line x1={10} y1={118} x2={700} y2={26} stroke={IVORY} strokeWidth={8} strokeLinecap="round"
            pathLength={100} strokeDasharray={100} strokeDashoffset={100 * (1 - crossP)} opacity={0.95} />
        </svg>
      )}
      <div style={{ marginTop: 18, fontFamily: DISPLAY, fontWeight: 700, fontSize: 27, letterSpacing: 6, color: CRIMSON_BRIGHT, opacity: subOp }}>
        {slam.sub}
      </div>
      <div style={{ marginTop: 12, height: 4, width: 340 * p, background: GOLD }} />
    </div>
  );
};

// ---------- hero (the heroine herself, first person) ----------
const HeroLayer: React.FC<{ hero: Unit["hero"][number] }> = ({ hero }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = usePop(hero.start);
  const hasGlide = hero.glide_at != null;
  const holdUntil = hero.hold_until ?? hero.end;
  const out = hasGlide
    ? interpolate(t, [holdUntil - 0.7, holdUntil], [1, 0], clamp)
    : interpolate(t, [hero.end - 0.5, hero.end], [1, 0], clamp);
  const g = hasGlide
    ? interpolate(t, [hero.glide_at as number, (hero.glide_at as number) + (hero.glide_dur ?? 1.6)], [0, 1], { ...clamp, easing: Easing.inOut(Easing.cubic) })
    : 0;
  const bx = hero.x ?? 72;
  const by = hero.y ?? 92;
  const bw = hero.w ?? 470;
  const px = bx + ((hero.gx ?? bx) - bx) * g;
  const py = by + ((hero.gy ?? by) - by) * g;
  const pw = bw + ((hero.gw ?? bw) - bw) * g;
  const ph = 545 * (pw / 470);
  const plate = interpolate(t, [hero.start + 0.9, hero.start + 1.6], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) }) * (1 - g);
  const glow = hero.glow_at != null
    ? fadeT(t, hero.glow_at, hero.glow_at + 0.8) * (1 - fadeT(t, hero.glow_back as number, (hero.glow_back as number) + 0.8))
    : 0;
  const quoteOp = fadeT(t, hero.start + 0.7, hero.start + 1.5) * out;
  if (t < hero.start - 0.1 || t > holdUntil + 0.1) return null;
  return (
    <div style={{ position: "absolute", inset: 0, zIndex: g > 0 ? 55 : 45, opacity: Math.min(1, p * 1.8) * out }}>
      {glow > 0.01 && (
        <div style={{
          position: "absolute", left: px - 26, top: py - 26, width: pw + 52, height: ph + 52,
          borderRadius: 18, boxShadow: `0 0 90px 26px rgba(193,39,45,${0.5 * glow})`,
        }} />
      )}
      <Panel src={hero.panel} x={px} y={py} w={pw} rot={-1.2} enterAt={hero.start} exitAt={hasGlide ? holdUntil + 10 : hero.end + 0.45} from="left" z={45} imgPos="50% 50%" hOverride={ph} videoSrc={hero.video ?? undefined} videoDur={hero.video_dur ?? undefined}>
        {hero.name_card && (
          <div style={{
            position: "absolute", left: 0, right: 0, bottom: 0,
            transform: `translateY(${(1 - plate) * 105}%)`,
            background: "rgba(10,8,6,0.9)", borderTop: `3px solid ${GOLD}`, padding: "10px 18px 12px",
          }}>
            <div style={{ fontFamily: DISPLAY, fontWeight: 900, fontSize: 37, letterSpacing: 2.5, color: IVORY, lineHeight: 1 }}>
              ELENA <span style={{ color: GOLD }}>VANCE</span>
            </div>
            <div style={{ fontFamily: DISPLAY, fontWeight: 700, fontSize: 16.5, letterSpacing: 4.5, color: CRIMSON_BRIGHT, marginTop: 5 }}>
              HER STORY — IN HER OWN VOICE
            </div>
          </div>
        )}
      </Panel>
      {hero.quote && (
        <div style={{
          position: "absolute", left: px + pw + 130, top: py + 58, width: 500, zIndex: 46, opacity: quoteOp,
          background: IVORY, color: "#241c12", padding: "22px 26px 20px",
          boxShadow: "0 22px 34px rgba(0,0,0,0.55)", transform: "rotate(1.1deg)",
        }}>
          <div style={{ width: 52, height: 4, background: CRIMSON, marginBottom: 14 }} />
          <div style={{ fontFamily: SERIF, fontStyle: "italic", fontSize: 23.5, lineHeight: 1.5 }}>
            “{hero.quote}”
          </div>
        </div>
      )}
    </div>
  );
};

// ---------- chapter title card (board style) ----------
const ChapterCard: React.FC<{ card: Unit["chapter_cards"][number]; sideHero?: boolean }> = ({ card, sideHero }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  if (t < card.start || t > card.end) return null;
  const op = Math.min(
    interpolate(t, [card.start, card.start + 0.35], [0, 1], clamp),
    interpolate(t, [card.end - 0.4, card.end], [1, 0], clamp));
  const fly = interpolate(t, [card.start + 0.1, card.start + 0.8], [46, 0], { ...clamp, easing: Easing.out(Easing.cubic) });
  const rule = interpolate(t, [card.start + 0.3, card.start + 0.9], [0, 1], clamp);
  return (
    <div style={{
      position: "absolute", inset: 0, zIndex: 50, background: "rgba(13,10,7,0.97)", opacity: op,
      display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center",
    }}>
      <div style={{ transform: `translateY(${fly}px)`, textAlign: "center", padding: sideHero ? "0 120px 0 360px" : "0 120px" }}>
        <div style={{ color: GOLD, fontFamily: DISPLAY, fontWeight: 800, fontSize: 30, letterSpacing: 14, marginBottom: 26 }}>
          {card.kicker}
        </div>
        <div style={{ color: IVORY, fontFamily: SERIF, fontSize: 58, lineHeight: 1.25 }}>
          {card.title}
        </div>
        <div style={{ width: 180, height: 3, background: CRIMSON_BRIGHT, margin: "34px auto 0", transform: `scaleX(${rule})` }} />
      </div>
    </div>
  );
};

// ---------- board light wash (mood: cools on the dark beats, OpeningV2 grammar) ----------
const Wash: React.FC<{ w: Unit["washes"][number] }> = ({ w }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const op = fadeT(t, w.in, w.in + w.inDur) * (1 - fadeT(t, w.out, w.out + w.outDur)) * 0.38;
  if (op <= 0.003) return null;
  return (
    <div style={{
      position: "absolute", inset: 0, zIndex: 80, pointerEvents: "none", opacity: op,
      background: "linear-gradient(170deg, rgba(16,22,44,0.85), rgba(6,8,18,0.9))",
    }} />
  );
};

// ---------- board devices (ported from Ep1 devices.tsx: map first) ----------
const ss01 = (x: number) => {
  const v = Math.max(0, Math.min(1, x));
  return v * v * (3 - 2 * v);
};

function usePopD(atSec: number, dur = 0.55) {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({
    frame: frame - Math.round(atSec * FPS),
    fps,
    config: { damping: 13, mass: 0.7, stiffness: 170 },
    durationInFrames: Math.round(dur * FPS),
  });
}

const DEV_W = 880;
const DEV_H = 474;

const DevTape: React.FC<{ style: React.CSSProperties }> = ({ style }) => (
  <div style={{ position: "absolute", width: 92, height: 24, background: "rgba(233,220,180,0.75)", boxShadow: "0 2px 5px rgba(0,0,0,.35)", zIndex: 30, ...style }} />
);

type DevData = Unit["devices"][number];

const DevFrame: React.FC<{ at: number; out: number; title?: string; w?: number; h?: number; paper?: boolean; children: React.ReactNode }> = ({ at, out, title, w = DEV_W, h = DEV_H, paper, children }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const pop = usePopD(at, 0.6);
  const fade = Math.max(0, Math.min(1, (out - t) / 0.5));
  if ((pop <= 0 && t < at) || fade <= 0) return null;
  return (
    <div style={{
      position: "absolute", left: 0, top: 0, width: w, height: h,
      opacity: pop * fade,
      transform: `translateY(${(1 - pop) * 46}px) scale(${0.94 + 0.06 * pop}) rotate(${(1 - pop) * -0.8}deg)`,
    }}>
      <div style={{
        position: "absolute", inset: 0, overflow: "hidden",
        background: paper
          ? "linear-gradient(180deg,#f3ead2,#e7d9b8)"
          : "radial-gradient(700px 420px at 300px 120px, #251b10 0%, #1a130a 58%, #120d07 100%)",
        border: `7px solid ${IVORY}`, boxShadow: "0 22px 26px rgba(0,0,0,.55)",
      }}>
        {children}
      </div>
      <DevTape style={{ left: 30, top: -13, transform: "rotate(-4deg)" }} />
      <DevTape style={{ right: 30, top: -13, transform: "rotate(3.5deg)" }} />
      {title ? (
        <div style={{
          position: "absolute", left: 20, top: 16, zIndex: 31, background: GOLD, color: "#191204",
          fontFamily: DISPLAY, fontWeight: 700, fontSize: 19, letterSpacing: 2.5,
          padding: "5px 14px 4px", whiteSpace: "nowrap", transform: "rotate(-1.2deg)",
          boxShadow: "0 4px 10px rgba(0,0,0,.4)",
        }}>{title}</div>
      ) : null}
    </div>
  );
};

const MapPin: React.FC<{ x: number; y: number; label: string; at: number; side?: "l" | "r" }> = ({ x, y, label, at, side = "r" }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = usePopD(at, 0.45);
  if (p <= 0 || t < at - 0.05) return null;
  const drop = (1 - p) * -26;
  return (
    <div style={{ position: "absolute", left: x, top: y, zIndex: 12 }}>
      <div style={{ position: "absolute", left: -12, top: -12 + drop, width: 24, height: 24, borderRadius: "50%", background: GOLD, border: "3px solid #14100c", boxShadow: "0 5px 9px rgba(0,0,0,.5)", transform: `scale(${0.5 + 0.5 * p})` }}>
        <div style={{ position: "absolute", left: 5.5, top: 5.5, width: 7, height: 7, borderRadius: "50%", background: CRIMSON_BRIGHT }} />
      </div>
      <div style={{
        position: "absolute", top: -13, whiteSpace: "nowrap",
        ...(side === "r" ? { left: 19 } : { right: 19 }),
        fontFamily: DISPLAY, fontWeight: 700, letterSpacing: 2, fontSize: 17.5, color: IVORY,
        background: "rgba(10,8,5,0.85)", padding: "4px 10px 3px", border: `1.5px solid ${GOLD}`,
        opacity: p, transform: `scale(${0.6 + 0.4 * p})`, transformOrigin: side === "r" ? "left center" : "right center",
      }}>{label}</div>
    </div>
  );
};

const MapDevice: React.FC<{ d: DevData }> = ({ d }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const W = DEV_W, H = DEV_H;
  const gridLines: React.ReactNode[] = [];
  for (let x = 40; x < W; x += 46) gridLines.push(<line key={`v${x}`} x1={x} y1={0} x2={x - 30} y2={H} stroke="rgba(239,230,208,0.055)" strokeWidth={7} />);
  for (let y = 30; y < H; y += 42) gridLines.push(<line key={`h${y}`} x1={0} y1={y} x2={W} y2={y + 14} stroke="rgba(239,230,208,0.045)" strokeWidth={7} />);
  let routeC = 0;
  const rp = d.route?.pts ?? [];
  for (let i = 1; i < rp.length; i++) routeC += Math.hypot(rp[i][0] - rp[i - 1][0], rp[i][1] - rp[i - 1][1]);
  const routeP = d.route ? ss01((t - d.route.at) / (d.route.dur ?? 2.6)) : 0;
  return (
    <DevFrame at={d.at} out={d.out} title={d.title}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", inset: 0 }}>
        {gridLines}
        <path d="M -10,420 C 220,380 420,452 640,408 C 760,386 830,404 890,388 L 890,484 L -10,484 Z" fill="#121c28" opacity={0.9} />
        {d.route && routeC > 0 ? (
          <polyline points={rp.map((p) => p.join(",")).join(" ")} fill="none" stroke={CRIMSON_BRIGHT} strokeWidth={4.5} strokeLinecap="round" strokeLinejoin="round"
            strokeDasharray={routeC} strokeDashoffset={routeC * (1 - routeP)}
            style={{ filter: "drop-shadow(0 2px 3px rgba(0,0,0,.5))" }} />
        ) : null}
      </svg>
      {(d.areas ?? []).map((a, i) => (
        <div key={i} style={{ position: "absolute", left: a.fx * W, top: a.fy * H, transform: `rotate(${a.rot ?? 0}deg)`, fontFamily: DISPLAY, fontWeight: 700, letterSpacing: 4, fontSize: 16, color: "rgba(217,164,65,0.55)", whiteSpace: "nowrap" }}>
          {a.label}
        </div>
      ))}
      {(d.points ?? []).map((p, i) => (
        <MapPin key={i} x={p.fx * W} y={p.fy * H} label={p.label} at={p.at} side={(p.side ?? "r") as "l" | "r"} />
      ))}
      <div style={{ position: "absolute", right: 22, top: 16, textAlign: "center", opacity: 0.75 }}>
        <div style={{ fontFamily: DISPLAY, fontWeight: 800, fontSize: 17, color: GOLD }}>N</div>
        <div style={{ width: 0, height: 0, margin: "1px auto 0", borderLeft: "6px solid transparent", borderRight: "6px solid transparent", borderBottom: `11px solid ${GOLD}` }} />
      </div>
    </DevFrame>
  );
};

// ---------- timeline device (ported from Ep1 devices.tsx) ----------
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));

const TimelineDevice: React.FC<{ d: DevData }> = ({ d }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const W = DEV_W, H = 300;
  const x0 = 74, x1 = W - 74;
  const axisY = 148;
  const prog = clamp01((t - d.at) / Math.max(1, d.out - d.at));
  const headX = x0 + prog * (x1 - x0);
  return (
    <DevFrame w={W} h={H} at={d.at} out={d.out} title={d.title}>
      <div style={{ position: "absolute", left: x0, top: axisY - 2, width: x1 - x0, height: 4, background: "rgba(239,230,208,0.28)" }} />
      {d.span ? (
        <div style={{ position: "absolute", left: x0 + d.span.a * (x1 - x0), top: axisY - 21, width: (d.span.b - d.span.a) * (x1 - x0), height: 42, background: "rgba(193,39,45,0.20)", borderTop: "2px solid rgba(224,72,62,0.7)", borderBottom: "2px solid rgba(224,72,62,0.7)", opacity: ss01((t - d.at - 0.5) / 0.8) }} />
      ) : null}
      <div style={{ position: "absolute", left: x0, top: axisY - 2, width: prog * (x1 - x0), height: 4, background: GOLD }} />
      <div style={{ position: "absolute", left: headX - 1.5, top: 78, width: 3, height: 142, background: GOLD, opacity: 0.9 }} />
      <div style={{ position: "absolute", left: headX - 8, top: axisY - 8, width: 16, height: 16, background: GOLD, transform: "rotate(45deg)", border: "2.5px solid #14100c", boxShadow: "0 3px 7px rgba(0,0,0,.5)" }} />
      <div style={{ position: "absolute", left: x0 - 6, top: axisY + 62, fontFamily: DISPLAY, fontWeight: 700, letterSpacing: 2, fontSize: 16, color: GOLD }}>{d.fromLabel}</div>
      <div style={{ position: "absolute", right: x0 - 6, top: axisY + 62, fontFamily: DISPLAY, fontWeight: 700, letterSpacing: 2, fontSize: 16, color: GOLD, textAlign: "right" }}>{d.toLabel}</div>
      {d.span ? (
        <div style={{ position: "absolute", left: x0 + ((d.span.a + d.span.b) / 2) * (x1 - x0), top: axisY + 34, transform: "translateX(-50%)", fontFamily: DISPLAY, fontWeight: 700, letterSpacing: 2.5, fontSize: 15.5, color: "#e0483e", whiteSpace: "nowrap", opacity: ss01((t - d.at - 0.8) / 0.8) }}>
          {d.span.label}
        </div>
      ) : null}
      {(d.pins ?? []).map((pin: any, i: number) => (
        <TimelinePin key={i} pin={pin} x0={x0} x1={x1} axisY={axisY} />
      ))}
    </DevFrame>
  );
};

const TimelinePin: React.FC<{ pin: any; x0: number; x1: number; axisY: number }> = ({ pin, x0, x1, axisY }) => {
  const p = usePopD(pin.at, 0.5);
  if (p <= 0) return null;
  const px = x0 + pin.frac * (x1 - x0);
  return (
    <div style={{ position: "absolute", left: px, top: 0, opacity: p }}>
      <div style={{ position: "absolute", left: -6.5, top: axisY - 6.5, width: 13, height: 13, background: CRIMSON_BRIGHT, transform: `rotate(45deg) scale(${0.5 + 0.5 * p})`, border: "2px solid #14100c" }} />
      <div style={{ position: "absolute", left: 0, top: axisY - 62, transform: "translateX(-50%)", fontFamily: DISPLAY, fontWeight: 800, letterSpacing: 1.5, fontSize: 20, color: GOLD, whiteSpace: "nowrap" }}>{pin.year}</div>
      <div style={{ position: "absolute", left: 0, top: axisY + 16, transform: "translateX(-50%)", width: 168, textAlign: "center", fontFamily: SERIF, fontStyle: "italic", fontSize: 16.5, lineHeight: 1.25, color: IVORY }}>{pin.label}</div>
    </div>
  );
};

// ---------- relationship board (ported; monogram nodes) ----------
const RelBoard: React.FC<{ d: DevData }> = ({ d }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const W = DEV_W, H = DEV_H;
  const nodes = d.nodes ?? [];
  const byId = new Map(nodes.map((n: any) => [n.id, n]));
  return (
    <DevFrame at={d.at} out={d.out} title={d.title}>
      <div style={{ position: "absolute", inset: 0, opacity: 0.5, backgroundImage: "radial-gradient(rgba(239,230,208,0.05) 1.2px, transparent 1.3px)", backgroundSize: "26px 26px" }} />
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
        {(d.links ?? []).map((lk: any, i: number) => {
          const a = byId.get(lk.a), b = byId.get(lk.b);
          if (!a || !b) return null;
          const mx = (a.bx + b.bx) / 2, my = (a.by + b.by) / 2 + 30 + Math.hypot(b.bx - a.bx, b.by - a.by) * 0.05;
          const len = Math.hypot(b.bx - a.bx, b.by - a.by) * 1.12;
          const p = ss01((t - lk.at) / 1.15);
          const col = lk.gold ? GOLD : CRIMSON_BRIGHT;
          return (
            <g key={i}>
              <path d={`M ${a.bx},${a.by} Q ${mx},${my} ${b.bx},${b.by}`} fill="none" stroke={col} strokeWidth={3.5} strokeLinecap="round" strokeDasharray={len} strokeDashoffset={len * (1 - p)} opacity={0.95} />
              <path d={`M ${a.bx},${a.by + 4} Q ${mx},${my + 4} ${b.bx},${b.by + 4}`} fill="none" stroke={col} strokeWidth={1.6} strokeDasharray={len} strokeDashoffset={len * (1 - p)} opacity={0.45} />
            </g>
          );
        })}
      </svg>
      {(d.links ?? []).map((lk: any, i: number) => {
        const a = byId.get(lk.a), b = byId.get(lk.b);
        if (!a || !b) return null;
        const p = usePopD(lk.at + 0.95, 0.45);
        if (p <= 0 || !lk.label) return null;
        const mx = (a.bx + b.bx) / 2, my = (a.by + b.by) / 2 + 15 + Math.hypot(b.bx - a.bx, b.by - a.by) * 0.025;
        const col = lk.gold ? GOLD : CRIMSON_BRIGHT;
        return (
          <div key={i} style={{ position: "absolute", left: mx, top: my, transform: `translate(-50%,-50%) scale(${0.6 + 0.4 * p}) rotate(-1.5deg)`, background: "rgba(10,8,5,0.92)", border: `2px solid ${col}`, color: IVORY, fontFamily: DISPLAY, fontWeight: 700, letterSpacing: 2, fontSize: 14.5, padding: "5px 11px 4px", whiteSpace: "nowrap", opacity: p, zIndex: 14, boxShadow: "0 5px 10px rgba(0,0,0,.5)" }}>
            {lk.label}
          </div>
        );
      })}
      {nodes.map((n: any) => (
        <RelNodeView key={n.id} n={n} />
      ))}
    </DevFrame>
  );
};

const RelNodeView: React.FC<{ n: any }> = ({ n }) => {
  const p = usePopD(n.at, 0.55);
  if (p <= 0) return null;
  const S = 108;
  return (
    <div style={{ position: "absolute", left: n.bx - S / 2, top: n.by - S / 2, width: S, zIndex: 12, opacity: p, transform: `scale(${0.55 + 0.45 * p}) rotate(${n.id.length % 2 ? 1.6 : -1.6}deg)` }}>
      <div style={{ position: "relative", width: S, height: S, borderRadius: "50%", overflow: "hidden", border: `3.5px solid ${IVORY}`, background: "#241a10", boxShadow: "0 10px 16px rgba(0,0,0,.55)" }}>
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: SERIF, fontWeight: 700, fontSize: 52, color: GOLD }}>
          {n.name.charAt(0)}
        </div>
      </div>
      <div style={{ position: "absolute", left: S / 2 - 7, top: -8, width: 14, height: 14, borderRadius: "50%", background: CRIMSON_BRIGHT, border: "2px solid #14100c", boxShadow: "0 3px 5px rgba(0,0,0,.5)" }} />
      <div style={{ position: "absolute", left: "50%", top: S + 7, transform: "translateX(-50%)", textAlign: "center", width: 190 }}>
        <div style={{ display: "inline-block", background: "rgba(10,8,5,0.9)", border: "1.5px solid rgba(239,230,208,0.5)", padding: "4px 10px 3px", fontFamily: DISPLAY, fontWeight: 700, letterSpacing: 2, fontSize: 15.5, color: IVORY, whiteSpace: "nowrap" }}>
          {n.name}
        </div>
        {n.sub ? <div style={{ marginTop: 4, fontFamily: SERIF, fontStyle: "italic", fontSize: 14.5, color: "rgba(239,230,208,0.88)", textShadow: "0 2px 5px rgba(0,0,0,.8)" }}>{n.sub}</div> : null}
      </div>
    </div>
  );
};

// ---------- split-screen contrast (ported) ----------
const SplitDevice: React.FC<{ d: DevData }> = ({ d }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const W = DEV_W, H = DEV_H;
  const wipe = ss01((t - d.at - 0.25) / 0.55);
  const drift = Math.sin((t - d.at) * 1.3) * 3.5 * wipe;
  const life = clamp01((t - d.at) / Math.max(1, d.out - d.at));
  const half = (img: string | undefined, label: string | undefined, sub: string | undefined, right: boolean, zoomIn: boolean) => (
    <div style={{ position: "absolute", top: 0, bottom: 0, ...(right ? { right: 0 } : { left: 0 }), width: W / 2, overflow: "hidden" }}>
      {img ? <Img src={staticFile(img)} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${zoomIn ? 1.03 + 0.06 * life : 1.09 - 0.06 * life})` }} /> : null}
      <div style={{ position: "absolute", inset: 0, background: right ? "linear-gradient(270deg, rgba(10,6,3,0.18), rgba(10,6,3,0.42))" : "linear-gradient(90deg, rgba(10,6,3,0.18), rgba(10,6,3,0.42))" }} />
      <div style={{ position: "absolute", top: 18, ...(right ? { right: 18 } : { left: 18 }), textAlign: right ? "right" : "left" }}>
        <div style={{ display: "inline-block", background: GOLD, color: "#191204", fontFamily: DISPLAY, fontWeight: 700, letterSpacing: 2.5, fontSize: 18, padding: "5px 13px 4px", transform: "rotate(-1.2deg)", boxShadow: "0 4px 10px rgba(0,0,0,.45)" }}>{label}</div>
        {sub ? <div style={{ marginTop: 7, fontFamily: SERIF, fontStyle: "italic", fontSize: 17, color: IVORY, textShadow: "0 2px 7px rgba(0,0,0,.85)" }}>{sub}</div> : null}
      </div>
    </div>
  );
  return (
    <DevFrame at={d.at} out={d.out}>
      {half(d.leftImg, d.leftLabel, d.leftSub, false, true)}
      {half(d.rightImg, d.rightLabel, d.rightSub, true, false)}
      <div style={{ position: "absolute", left: W / 2 - 2 + drift, top: 0, width: 4, height: H * wipe, background: GOLD, boxShadow: "0 0 14px rgba(217,164,65,.55)", zIndex: 8 }} />
      {wipe > 0.9 ? (
        <div style={{ position: "absolute", left: W / 2 - 9 + drift, top: H / 2 - 9, width: 18, height: 18, background: GOLD, transform: "rotate(45deg)", border: "2.5px solid #14100c", zIndex: 9, boxShadow: "0 3px 8px rgba(0,0,0,.5)" }} />
      ) : null}
      {d.verdict ? <Stamp x={W / 2 - 130} y={H - 92} at={d.at + (d.out - d.at) * 0.55} outAt={d.out} text={d.verdict} size={26} /> : null}
    </DevFrame>
  );
};

// ---------- object annotation diagram (ported) ----------
const ObjectDevice: React.FC<{ d: DevData }> = ({ d }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const W = DEV_W, H = DEV_H;
  const AX = 18, AY = 18, AW = W - 36, AH = H - 36;
  const crop = d.crop ?? { x: 0, y: 0, w: 1, h: 1 };
  const scale = Math.max(AW / (crop.w * 1168), AH / (crop.h * 658));
  const imgW = 1168 * scale, imgH = 658 * scale;
  const offX = AX + (AW - crop.w * imgW) / 2 - crop.x * imgW;
  const offY = AY + (AH - crop.h * imgH) / 2 - crop.y * imgH;
  const pt = (nx: number, ny: number) => ({
    x: AX + (crop.x + nx * crop.w) * imgW - crop.x * imgW + (AW - crop.w * imgW) / 2,
    y: AY + (crop.y + ny * crop.h) * imgH - crop.y * imgH + (AH - crop.h * imgH) / 2,
  });
  return (
    <DevFrame at={d.at} out={d.out} title={d.title}>
      <div style={{ position: "absolute", left: AX, top: AY, width: AW, height: AH, overflow: "hidden", border: "2px solid rgba(239,230,208,0.35)" }}>
        {d.img ? <Img src={staticFile(d.img)} style={{ position: "absolute", left: offX - AX, top: offY - AY, width: imgW, height: imgH, maxWidth: "none" }} /> : null}
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(600px 340px at 50% 46%, transparent 55%, rgba(8,5,3,0.42) 100%)" }} />
      </div>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", inset: 0, overflow: "visible", zIndex: 10 }}>
        {(d.notes ?? []).map((nt: any, i: number) => {
          const p0 = pt(nt.x, nt.y);
          const ax = nt.side === "l" ? AX + 128 : AX + AW - 128;
          const len = Math.abs(ax - p0.x);
          const pr = ss01((t - nt.at) / 0.6);
          return (
            <g key={i}>
              <line x1={p0.x} y1={p0.y} x2={ax} y2={p0.y} stroke={GOLD} strokeWidth={2.5} strokeDasharray={len} strokeDashoffset={len * (1 - pr)} />
              <circle cx={p0.x} cy={p0.y} r={6} fill={GOLD} stroke={CRIMSON_BRIGHT} strokeWidth={2.5} opacity={pr} />
            </g>
          );
        })}
      </svg>
      {(d.notes ?? []).map((nt: any, i: number) => (
        <ObjNote key={i} nt={nt} pt={pt(nt.x, nt.y)} ax={nt.side === "l" ? AX + 128 : AX + AW - 128} />
      ))}
    </DevFrame>
  );
};

const ObjNote: React.FC<{ nt: any; pt: { x: number; y: number }; ax: number }> = ({ nt, pt, ax }) => {
  const p = usePopD(nt.at + 0.45, 0.45);
  if (p <= 0) return null;
  const right = nt.side === "r";
  return (
    <div style={{ position: "absolute", left: ax, top: pt.y, zIndex: 11, transform: `translate(${right ? "-100%" : "0"}, -50%) scale(${0.6 + 0.4 * p})`, transformOrigin: right ? "right center" : "left center", opacity: p, textAlign: right ? "right" : "left" }}>
      <div style={{ display: "inline-block", background: "rgba(10,8,5,0.9)", border: `2px solid ${GOLD}`, padding: "6px 12px 5px", whiteSpace: "nowrap" }}>
        <div style={{ fontFamily: DISPLAY, fontWeight: 700, letterSpacing: 2, fontSize: 16.5, color: IVORY }}>{nt.label}</div>
        {nt.sub ? <div style={{ fontFamily: SERIF, fontStyle: "italic", fontSize: 14.5, color: GOLD, marginTop: 2 }}>{nt.sub}</div> : null}
      </div>
    </div>
  );
};

// ---------- redacted document reveal (ported) ----------
const RedactDoc: React.FC<{ d: DevData }> = ({ d }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  return (
    <DevFrame w={800} at={d.at} out={d.out} paper>
      <div style={{ position: "absolute", inset: 0, padding: "30px 44px", transform: "rotate(-0.4deg)", fontFamily: SERIF, color: "#241a10" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontFamily: DISPLAY, fontWeight: 800, letterSpacing: 3, fontSize: 21, color: "#7c1f16" }}>{d.title}</div>
            <div style={{ marginTop: 6, height: 3, width: 300, background: "#7c1f16", opacity: 0.75 }} />
          </div>
          {d.stamp ? (
            <div style={{ border: `3.5px solid ${CRIMSON_BRIGHT}`, color: "#b03030", fontFamily: DISPLAY, fontWeight: 800, letterSpacing: 3, fontSize: 16, padding: "5px 12px 4px", borderRadius: 5, transform: "rotate(-6deg)", opacity: 0.85 }}>
              {d.stamp}
            </div>
          ) : null}
        </div>
        <div style={{ marginTop: 30 }}>
          {(d.docLines ?? []).map((ln: any, i: number) => (
            <DocLine key={i} ln={ln} t={t} />
          ))}
        </div>
        <div style={{ position: "absolute", left: 44, bottom: 24, fontFamily: DISPLAY, letterSpacing: 3, fontSize: 12.5, color: "rgba(36,26,16,0.55)" }}>
          — RECREATED FROM THE RECORD —
        </div>
      </div>
    </DevFrame>
  );
};

const DocLine: React.FC<{ ln: any; t: number }> = ({ ln, t }) => {
  const base: React.CSSProperties = { position: "relative", fontSize: 22.5, lineHeight: 1.42, marginBottom: 17, minHeight: 32, whiteSpace: "nowrap" };
  if (ln.type) {
    const total = ln.text.length;
    const n = Math.max(0, Math.min(total, Math.floor((t - ln.at) / 0.03)));
    if (t < ln.at) return <div style={{ ...base, opacity: 0 }}>{ln.text}</div>;
    const cursor = Math.sin(t * 9) > -0.2;
    return (
      <div style={{ ...base, fontWeight: 700, color: "#7c1f16" }}>
        {ln.text.slice(0, n)}
        <span style={{ opacity: cursor ? 0.9 : 0 }}>▌</span>
      </div>
    );
  }
  if (ln.secret) {
    const lift = ss01((t - ln.at) / 0.75);
    if (t < ln.at - 1.2) return <div style={{ ...base, opacity: 0 }}>{ln.text}</div>;
    const appear = ss01((t - (ln.at - 1.2)) / 0.4);
    const barW = Math.min(ln.text.length * 12.6 + 14, 712);
    return (
      <div style={{ ...base, opacity: appear, fontWeight: 700, color: "#8e1f16", letterSpacing: 0.4 }}>
        {ln.text}
        <div style={{ position: "absolute", left: -7, top: 1, width: barW, height: 29, background: "#171208", transform: `scaleX(${1 - lift})`, transformOrigin: "left center", boxShadow: "0 2px 4px rgba(0,0,0,.3)" }} />
      </div>
    );
  }
  const o = ss01((t - ln.at) / 0.4);
  return <div style={{ ...base, opacity: o }}>{ln.text}</div>;
};

// ---------- camera ----------
function useCamera(unit: Unit) {
  const frame = useCurrentFrame();
  const cam = unit.camera;
  const times = cam.map((k) => k[0]);
  const pick = (i: number) =>
    interpolate(frame / FPS, times, cam.map((k) => k[i]), { ...clamp, easing: Easing.inOut(Easing.cubic) });
  const s = pick(1);
  const cx = pick(2);
  const cy = pick(3);
  return `translate(${640 - cx * s}px, ${360 - cy * s}px) scale(${s})`;
}

// ---------- main ----------
export const VoxEpisode: React.FC<{ unitId: string }> = ({ unitId }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const unit = vox.units.find((u) => u.id === unitId) ?? vox.units[0];
  const camera = useCamera(unit);
  const fadeIn = unit.start === 0 ? interpolate(t, [0, 0.45], [0, 1], clamp) : 1;
  const isLast = unit.end > 6036;
  const fadeOut = isLast ? interpolate(t, [unit.end - unit.start - 0.55, unit.end - unit.start], [0, 0.65], clamp) : 0;

  return (
    <AbsoluteFill style={{ background: INK, fontFamily: SANS }}>
      <Audio src={staticFile(vox.audio)} startFrom={Math.round(unit.start * FPS)} endAt={Math.round(unit.end * FPS)} />

      {/* screen-space board (1280x720 scaled to 1920x1080) with camera inside */}
      <div style={{ position: "absolute", width: 1920, height: 1080, overflow: "hidden" }}>
        <div style={{ position: "absolute", width: 1280, height: 720, transformOrigin: "0 0", transform: `scale(1.5)` }}>
          <div style={{ position: "absolute", width: 1280, height: 720, transformOrigin: "0 0", transform: camera }}>
            {/* board texture (wide film-strip board: width from unit data) */}
            <div style={{
              position: "absolute", left: 0, top: 0, width: unit.boardW ?? 1280, height: 720,
              background:
                "radial-gradient(1150px 680px at 32% 18%, rgba(217,164,65,0.075), rgba(0,0,0,0) 60%)," +
                "radial-gradient(rgba(239,230,208,0.05) 1px, rgba(0,0,0,0) 1.7px)," +
                "linear-gradient(160deg, #171209 0%, #120e09 55%, #0d0a07 100%)",
              backgroundSize: "auto, 26px 26px, auto",
            }} />
            {unit.ghosts.map((g, i) => {
              const op = fadeT(t, g.at, g.at + 0.6, g.out - 0.6, g.out);
              if (op <= 0.01) return null;
              return (
                <div key={`gh${i}`} style={{
                  position: "absolute", left: g.x, top: g.y, zIndex: 1, opacity: op,
                  fontFamily: SERIF, fontStyle: "italic", fontWeight: 700, fontSize: 110,
                  color: "rgba(239,230,208,0.075)", whiteSpace: "nowrap", pointerEvents: "none",
                }}>{g.text}</div>
              );
            })}
            {unit.ghost !== "" && (
              <div style={{ position: "absolute", right: 6, top: 120, fontFamily: SERIF, fontSize: 430, color: "rgba(239,230,208,0.045)", fontStyle: "italic", zIndex: 0 }}>
                {unit.ghost}
              </div>
            )}

            {unit.panels.filter((p) => !p.fullbleed).map((p, i) => (
              <Panel key={p.scene} src={p.src} x={p.x} y={p.y} w={p.w} rot={p.rot}
                enterAt={p.start} exitAt={p.end} from={p.side === "L" ? "left" : "right"} z={10 + i} videoSrc={p.video ?? undefined} videoDur={p.video_dur ?? undefined} shakeAt={p.shake ?? undefined} />
            ))}
            {unit.flashbacks.map((f, i) => (
              <Panel key={`fb${i}`} src={f.src} x={f.x} y={f.y} w={f.w} rot={f.rot}
                enterAt={f.at} exitAt={f.at + f.dur} from="right" z={48} />
            ))}
            {unit.devices.map((d, i) => (
              <div key={`dev${i}`} style={{ position: "absolute", left: d.x, top: d.y, zIndex: 42, transform: `scale(${d.scale ?? 1})`, transformOrigin: "0 0" }}>
                {d.type === "map" ? <MapDevice d={d} />
                  : d.type === "timeline" ? <TimelineDevice d={d} />
                  : d.type === "relboard" ? <RelBoard d={d} />
                  : d.type === "split" ? <SplitDevice d={d} />
                  : d.type === "object" ? <ObjectDevice d={d} />
                  : d.type === "redact" ? <RedactDoc d={d} />
                  : null}
              </div>
            ))}
            {unit.notecards.map((c, i) => <NoteCard key={i} card={c} />)}
            {unit.tags.map((tg, i) => <Tag key={i} x={tg.x} y={tg.y} text={tg.text} at={tg.at} outAt={tg.outAt} />)}
            {unit.stamps.map((s, i) => <Stamp key={i} x={s.x} y={s.y} text={s.text} at={s.at} outAt={s.outAt} size={s.size ?? 30} />)}

            <svg style={{ position: "absolute", left: 0, top: 0, zIndex: 46, pointerEvents: "none" }} width={unit.boardW ?? 1280} height={720} viewBox={`0 0 ${unit.boardW ?? 1280} 720`}>
              {unit.ellipses.map((e, i) => <DrawEllipse key={i} cx={e.cx} cy={e.cy} rx={e.rx} ry={e.ry} at={e.at} end={e.end} />)}
            </svg>

            {unit.slams.map((s, i) => <Slam key={i} slam={s} />)}
            {unit.hero.map((h, i) => <HeroLayer key={i} hero={h} />)}

          </div>

          {/* chapter cards are SCREEN space: inside the camera div they would sit
              at board origin and slide off-screen on the wide film-strip board */}
          {unit.chapter_cards.map((c, i) => <ChapterCard key={i} card={c} sideHero={unit.hero.some((h) => h.glide_at != null)} />)}

          {/* screen-space vignette (outside the camera div: the wide board must not drag it along) */}
          <div style={{ position: "absolute", inset: 0, zIndex: 60, pointerEvents: "none", background: "radial-gradient(ellipse at 50% 46%, rgba(0,0,0,0) 52%, rgba(0,0,0,0.5) 100%)" }} />

          {unit.washes.map((w, i) => <Wash key={i} w={w} />)}

          {/* chapter progress hairline (Ep1 NarUnit grammar) */}
          <div style={{ position: "absolute", left: 0, bottom: 0, height: 3, zIndex: 94, pointerEvents: "none",
            width: 1280 * Math.min(1, Math.max(0, t / (unit.end - unit.start))),
            background: "linear-gradient(90deg,#8a6420,#d9a441)", opacity: 0.55 }} />

          {/* kicker (board space, screen-fixed) */}
          <div style={{ position: "absolute", top: 20, left: 30, zIndex: 95, opacity: 0.9 }}>
            <div style={{ fontFamily: DISPLAY, fontWeight: 800, fontSize: 16, letterSpacing: 5, color: GOLD }}>MOONVEIL STORIES</div>
            <div style={{ fontFamily: DISPLAY, fontWeight: 600, fontSize: 13.5, letterSpacing: 3.5, color: "rgba(239,230,208,0.75)", marginTop: 3 }}>
              {unit.kicker}
            </div>
            <div style={{ height: 2, width: 210, background: CRIMSON, marginTop: 7 }} />
          </div>
        </div>

        {/* full-bleed cinematic accents (screen space) */}
        {unit.panels.filter((p) => p.fullbleed).map((p) => {
          const op = fadeT(t, p.start, p.start + 0.5, p.end - 0.5, p.end);
          if (op <= 0) return null;
          const scale = interpolate(t, [p.start, p.end], [1.02, 1.09], clamp);
          return (
            <div key={p.scene} style={{ position: "absolute", inset: 0, zIndex: 70, opacity: op, background: "#000" }}>
              {p.video ? (
                <Sequence from={Math.round(p.start * FPS)} durationInFrames={Math.round((p.end - p.start) * FPS)} layout="none">
                  <Loop durationInFrames={Math.max(1, Math.round((p.video_dur ?? 10) * FPS))}>
                    <OffthreadVideo src={staticFile(p.video)} muted style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${scale})` }} />
                  </Loop>
                </Sequence>
              ) : (
                <Img src={staticFile(p.src)} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${scale})` }} />
              )}
            </div>
          );
        })}

        {/* captions above everything, in board scale */}
        <div style={{ position: "absolute", width: 1280, height: 720, transformOrigin: "0 0", transform: "scale(1.5)", zIndex: 96, pointerEvents: "none" }}>
          <Captions unit={unit} />
        </div>

        <div style={{ position: "absolute", inset: 0, background: "#000", opacity: (1 - fadeIn) + fadeOut, pointerEvents: "none", zIndex: 200 }} />
      </div>
    </AbsoluteFill>
  );
};
