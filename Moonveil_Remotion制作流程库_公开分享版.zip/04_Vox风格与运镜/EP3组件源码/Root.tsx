import React from "react";
import { Composition } from "remotion";
import { VoxEpisode } from "./VoxEpisode";
import vox from "./vox_timeline.json";

export const Root: React.FC = () => {
  const fps = vox.fps;
  return (
    <>
      {vox.units.map((u) => (
        <Composition
          key={u.id}
          id={u.id}
          component={VoxEpisode}
          durationInFrames={Math.round((u.end - u.start) * fps)}
          fps={fps}
          width={vox.width}
          height={vox.height}
          defaultProps={{ unitId: u.id }}
        />
      ))}
    </>
  );
};
