import React from 'react';
import {AbsoluteFill, Html5Audio, Html5Video, OffthreadVideo, Sequence, getRemotionEnvironment, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import data from './vox_timeline.json';

const C={ink:'#101113',paper:'#e9dfc9',gold:'#c8aa72',red:'#943d38',white:'#f6f1e7'};
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const serif='Baskerville, "Times New Roman", serif';
const sans='"Helvetica Neue", Arial, sans-serif';
const script='"Snell Roundhand", "Apple Chancery", cursive';
const unit=data.units[0];
function fade(t:number,a:number,b:number,out?:number){return interpolate(t,[a,b],[0,1],clamp)*(out===undefined?1:interpolate(t,[out-.35,out],[1,0],clamp));}

const FilmImage:React.FC<{src:string,video?:boolean,close?:boolean,warm?:boolean,at:number}> = ({src,video=false,close=false,warm=false,at})=>{
 const t=useCurrentFrame()/30;const drift=interpolate(t,[at,at+18],[1.005,1.045],clamp);
 const VideoLayer=getRemotionEnvironment().isRendering?OffthreadVideo:Html5Video;
 const style:React.CSSProperties={width:'100%',height:'100%',objectFit:'cover',objectPosition:close?'18% 37%':warm?'50% 42%':'50% 43%',transform:video?'none':`scale(${close?2.12:drift})`,transformOrigin:close?'18% 37%':'50% 45%',filter:warm?'saturate(.75) contrast(1.04) brightness(.86)':'saturate(.70) contrast(1.05) brightness(.90)'};
 return <AbsoluteFill style={{overflow:'hidden',top:76,bottom:140,height:'auto'}}>
   {video?<div style={{position:'absolute',inset:0}}><Sequence from={Math.round(at*30)} durationInFrames={300} layout="none"><div style={{position:'absolute',inset:0}}><VideoLayer src={staticFile(src)} muted style={style}/></div></Sequence></div>:<Img src={staticFile(src)} style={style}/>}
   <AbsoluteFill style={{background:warm?'linear-gradient(90deg,rgba(25,17,12,.28),transparent 50%,rgba(10,11,13,.42)),linear-gradient(0deg,rgba(10,11,13,.85),transparent 48%)':'linear-gradient(90deg,rgba(5,15,22,.12),transparent 55%,rgba(5,11,17,.4)),linear-gradient(0deg,rgba(8,12,17,.9),transparent 55%)'}}/>
 </AbsoluteFill>;
};
const Small:React.FC<{children:React.ReactNode,style?:React.CSSProperties}>=({children,style})=><div style={{fontFamily:sans,fontSize:18,letterSpacing:4,fontWeight:500,...style}}>{children}</div>;

function Captions({t,diary}:{t:number,diary:boolean}){
 const c=unit.captions.find(c=>t>=c.start&&t<c.end);if(!c)return null;
 return <div style={{position:'absolute',left:140,right:140,bottom:26,display:'flex',justifyContent:'center',zIndex:30}}>
  <div style={{fontFamily:sans,fontSize:35,lineHeight:1.35,fontWeight:500,textAlign:'center',color:C.white,maxWidth:1500,textShadow:'0 2px 6px #000',opacity:fade(t,c.start,c.start+.09)}}>
  {c.words.map((w,i)=>{const current=t>=w.start&&t<w.end;return <span key={i} style={{color:current?C.gold:C.white,borderBottom:current?'2px solid '+C.gold:'2px solid transparent',paddingBottom:2,marginRight:9}}>{w.text}</span>})}
  </div>
 </div>;
}

export const NoirDiary:React.FC=()=>{
 const frame=useCurrentFrame();const t=frame/30;const diary=t>=40.688&&t<59.394;const wedding=t>=59.394;const close=false;
 const intro=fade(t,0,.35,3.626);const diaryP=fade(t,40.688,41.12);const tail=interpolate(t,[72.55,73.133],[1,0],clamp);
 return <AbsoluteFill style={{background:C.ink,color:C.white,overflow:'hidden',opacity:tail}}>
  <Html5Audio src={staticFile('full_audio_ep3_sfx.m4a')}/>
  {!diary&&(t<3.626?<FilmImage src="v17/ch01-head.png" at={0}/>:t<13.626?<FilmImage src="v17/delivery.mp4" video at={3.626}/>:t<23.626?<FilmImage src="v17/ch01-hospital-loop.mp4" video at={13.626}/>:t<27.286?<FilmImage src="v17/ch01-corridor.png" at={23.626}/>:t<40.688?<FilmImage src="v17/ch01-codeblue.png" at={27.286}/>:<FilmImage src="v17/ch01-julian-study.png" warm at={59.394}/>)}
  {diary&&<AbsoluteFill style={{background:C.paper,top:76,bottom:140,height:'auto',color:'#28251f',opacity:diaryP}}>
    <AbsoluteFill style={{background:'repeating-linear-gradient(0deg,transparent 0px,transparent 45px,rgba(91,71,42,.045) 46px,transparent 47px),radial-gradient(ellipse at 20% 40%,#f2e8d3,transparent 70%)'}}/>
    <div style={{position:'absolute',left:980,top:0,bottom:0,width:42,background:'linear-gradient(90deg,transparent,#56442d26,transparent)'}}/>
    <Small style={{position:'absolute',left:105,top:70,color:'#8a7150'}}>FROM MY JOURNAL / NEW YORK</Small>
    <div style={{position:'absolute',left:100,top:153,fontFamily:serif,fontSize:88,lineHeight:1.02}}>Seven years<br/><span style={{fontStyle:'italic'}}>earlier.</span></div>
    <div style={{position:'absolute',left:106,top:410,width:750,fontFamily:script,fontSize:63,lineHeight:1.18,transform:'rotate(-3deg)',opacity:fade(t,42.5,43)}}>I thought it meant<br/><span style={{color:'#9d7442'}}>safety.</span></div>
    <div style={{position:'absolute',left:112,top:660,right:1030,borderTop:'1px solid #9b89674d',paddingTop:20,opacity:fade(t,44.463,44.7)}}>
      <Small style={{fontSize:21,letterSpacing:2}}>AGE 26 · JUNIOR ATTORNEY</Small>
      <Small style={{fontSize:18,letterSpacing:2,marginTop:15,opacity:fade(t,47.75,48.05)}}>NEW YORK STATE BAR — PASSED</Small>
    </div>
    <div style={{position:'absolute',left:1084,top:70,width:652,height:700,padding:20,paddingBottom:72,boxSizing:'border-box',background:'#f8f3e6',boxShadow:'5px 12px 24px #3a2c242e',transform:`translateY(${(1-diaryP)*25}px) rotate(2deg)`}}>
     <Img src={staticFile('v17/ch02-lawfirm.png')} style={{width:'100%',height:'100%',objectFit:'cover',objectPosition:'40% 42%',filter:'saturate(.62) sepia(.13)'}}/>
     <div style={{position:'absolute',bottom:16,left:25,fontFamily:script,fontSize:31,color:'#4f4438'}}>Before I knew the price.</div>
    </div>
  </AbsoluteFill>}
  <div style={{position:'absolute',left:0,right:0,top:0,height:76,background:'#0c0d0f',borderBottom:'1px solid #bca77c25',display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 72px',zIndex:40}}>
    <Small style={{color:C.gold,fontSize:17,letterSpacing:5}}>MOONVEIL STORIES</Small>
    <Small style={{color:'#b3b1aa',fontSize:15,letterSpacing:3}}>01 / BLOOD ON THE DELIVERY BED</Small>
  </div>
  <div style={{position:'absolute',bottom:0,left:0,right:0,height:140,background:'#0c0d0f',zIndex:20,borderTop:'1px solid #bca77c20'}}/>
  {t<3.626&&<div style={{position:'absolute',left:100,top:520,zIndex:15,opacity:intro}}>
   <Small style={{color:C.gold,marginBottom:25}}>CHAPTER ONE</Small>
   <div style={{fontFamily:serif,fontSize:116,lineHeight:.96,letterSpacing:-2,textShadow:'0 4px 24px #0008'}}>Blood on the<br/><span style={{fontStyle:'italic'}}>delivery bed.</span></div>
  </div>}
  {t>=3.476&&t<13.86&&<div style={{position:'absolute',left:100,top:125,opacity:fade(t,3.476,3.7,13.86)}}>
    <Small style={{fontSize:16,color:'#dedfdb',letterSpacing:3}}>MOUNT SINAI · NEW YORK</Small>
    <div style={{marginTop:14,width:44,height:2,background:C.gold}}/>
  </div>}
  {t>=7.9&&t<13.86&&<div style={{position:'absolute',right:110,top:590,width:340,padding:'18px 24px',background:'#111a20bd',borderLeft:'2px solid '+C.gold,opacity:fade(t,7.9,8.15,13.86)}}>
    <Small style={{fontSize:14,letterSpacing:2,color:'#c9c7ba'}}>CARDIAC MONITOR</Small>
    <svg viewBox="0 0 300 60" style={{width:300,height:60,marginTop:12}}><path d="M0 36 H55 L64 27 L73 43 L82 6 L91 55 L101 36 H170 L181 28 L190 42 L200 8 L210 52 L221 36 H300" stroke={C.gold} strokeWidth="1.8" fill="none"/><line x1={(t*65)%300} x2={(t*65)%300} y1="0" y2="60" stroke="#fff" opacity=".25"/></svg>
  </div>}
  {t>=31.886&&t<40.688&&<div style={{position:'absolute',right:100,top:650,width:400,background:'#111820d9',padding:'24px 28px',borderTop:'1px solid '+C.red,opacity:fade(t,31.886,32.15,40.688)}}>
    <Small style={{fontSize:13,letterSpacing:3,color:'#b6c0c2'}}>HOSPITAL RECORD</Small>
    <div style={{fontFamily:serif,fontSize:36,marginTop:12}}>Catastrophic shock.</div>
    <Small style={{fontSize:14,letterSpacing:2,color:'#c39a8a',marginTop:10}}>PRIVATE OBSTETRICS SUITE</Small>
  </div>}
  {wedding&&<>
    <div style={{position:'absolute',left:100,top:135,opacity:fade(t,60.644,60.95)}}><Small style={{color:C.gold,fontSize:15}}>THE DELUCA FAMILY</Small><div style={{fontFamily:serif,fontSize:60,marginTop:12}}>Julian DeLuca</div><Small style={{fontSize:16,letterSpacing:3,color:'#c5c3ba',marginTop:10}}>MY HUSBAND</Small></div>
    <div style={{position:'absolute',right:100,bottom:205,width:480,textAlign:'right',opacity:fade(t,63.619,64)}}><Small style={{fontSize:16,color:C.gold,letterSpacing:2}}>DON VINCENT DELUCA</Small><div style={{fontFamily:serif,fontStyle:'italic',fontSize:35,color:'#ece4d6',marginTop:12}}>The family behind the promise.</div><Small style={{fontSize:13,letterSpacing:3,marginTop:12,color:'#b9b3a6'}}>LONG ISLAND COMPOUND</Small></div>
  </>}
  <Captions t={t} diary={diary}/>
  <div style={{position:'absolute',bottom:139,left:0,height:2,width:1920*t/73.133,background:C.gold,opacity:.5,zIndex:35}}/>
 </AbsoluteFill>;
};
