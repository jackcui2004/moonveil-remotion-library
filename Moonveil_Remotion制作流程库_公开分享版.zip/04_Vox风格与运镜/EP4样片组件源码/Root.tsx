import React from 'react';
import {Composition} from 'remotion';
import {VoxEpisode} from './VoxEpisode';
import {NoirDiary} from './NoirDiary';
export const Root:React.FC=()=> <>
 <Composition id="preview-ep4" component={VoxEpisode} fps={30} width={1920} height={1080} durationInFrames={2194} defaultProps={{unitId:'unit-ep4-opening'}}/>
 <Composition id="preview-noir-diary" component={NoirDiary} fps={30} width={1920} height={1080} durationInFrames={2194}/>
</>;
