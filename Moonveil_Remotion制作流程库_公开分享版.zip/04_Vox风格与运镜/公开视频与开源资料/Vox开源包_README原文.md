# Vox-Style Animation

**The editorial "Vox look" as a reusable style pack — plus the method to capture *any* style into a pack of your own.**

This is the recipe behind [the Vox-style motion-graphics video][video]: the
"printed, not lit" register — cream paper, halftone dots, heavy ink type, one
yellow highlighter marker, hand-drawn annotations, and paper slap-ins. It's built
on [HyperFrames][hf] (which renders video from HTML), so an AI coding agent can
build in this style on demand.

![Vox-style demo — how this repo works](examples/how-it-works/render/how-it-works.gif)

> ▶️ Full demo (with the "make any style yours" beat): [`examples/how-it-works/render/how-it-works.mp4`](examples/how-it-works/render/how-it-works.mp4) — a Vox-style explainer *about* this repo, built *with* this repo.

## Two things you get

1. **The whole Vox look**, ready to build with — palette, type, motion vocabulary, texture system, and the process laws that took nine drafts to earn.
2. **The method to do this yourself** with *any* aesthetic. See a style you love anywhere, capture its rules, and mint your own pack: **[skills/vox-style-animation/references/capture-your-own-style.md](skills/vox-style-animation/references/capture-your-own-style.md)**. That method is the real transferable skill.

## Install

This is a **HyperFrames style pack**, not a standalone renderer — install HyperFrames first, then this pack:

```bash
npx skills add heygen-com/hyperframes          # the framework + its skills
npx skills add Cele-san/vox-style-animation    # this style pack
```

Both are just markdown + assets — you can also open the `skills/` folder and read them as documentation without an AI agent.

## Quickstart — render the starter

A self-contained, renderable one-scene project lives in
[`skills/vox-style-animation/assets/starter/`](skills/vox-style-animation/assets/starter/):

```bash
cd skills/vox-style-animation/assets/starter
npx hyperframes render . -o out.mp4
```

You'll get a 6-second clip demonstrating the four core moves — paper slap-in,
highlighter swipe, dot-field stutter, and the sheet-wipe. Duplicate the scene,
change the copy, chain more scenes, and you're building.

## What's inside

```
skills/vox-style-animation/
  SKILL.md                       # the recipe (palette, type, motion, laws) — triggerable + readable
  references/
    capture-your-own-style.md    # ⭐ the 7-step method: any style -> your own pack
    motion-vocabulary.md         # every move's full recipe + tuned defaults
    asset-pipeline.md            # halftone/archival cutout generation
    overlay-pack.md              # transparent alpha overlays for footage (NLE)
  assets/
    brand-tokens.css             # palette (one job per color) + reusable classes
    starter/                     # renderable one-scene project to copy
  scripts/                       # gen_archival_objects.py, halftone_objects.py
examples/
  how-it-works/                  # the meta demo (this repo explaining itself)
```

## Adding narration

The demo ships caption-driven so it renders with zero audio dependencies. To
narrate any piece, the pack teaches the **VO-first** workflow (the timeline is
audio-locked): drop your VO file in `assets/`, add an `<audio class="clip">`
element in `index.html`, and re-time each scene to the words. See
[`references/motion-vocabulary.md`](skills/vox-style-animation/references/motion-vocabulary.md).

## Credits

- Built on **[HyperFrames][hf]** by HeyGen — the HTML-to-video framework. This
  repo is an independent style pack; it does not redistribute HyperFrames.
- The Vox techniques are researched, not guessed — drawn from Vox's own motion
  team and explainer-motion literature: **Estelle Caswell** (Vox / School of
  Motion), **Joey Sendaydiego** (Storybench), **PremiumBeat**, and **No Film
  School**.
- Recipe, pack, and demo by **[Andy Diep / diepandy][video]**.

## License

MIT — see [LICENSE](LICENSE).

[hf]: https://github.com/heygen-com/hyperframes
[video]: https://www.youtube.com/@diepandy
