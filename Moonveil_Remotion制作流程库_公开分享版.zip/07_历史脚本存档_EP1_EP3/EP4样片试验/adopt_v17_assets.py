from pathlib import Path
import shutil,json
P=Path(__file__).resolve().parents[1];SRC=P.parent/'EP4_v17_素材/ep4_assets_delivery';DST=P/'public/v17';shutil.copytree(SRC,DST,dirs_exist_ok=True)
chapters=[]
video_map={1:['delivery.mp4','ch01-hospital-loop.mp4'],3:['rain.mp4'],7:['dinner.mp4'],9:['cafe.mp4'],10:['office.mp4','stage.mp4']}
for i in range(1,11):
 chapters.append({'chapter':i,'images':[str(f.relative_to(DST)) for f in sorted(DST.glob(f'ch{i:02d}-*.png'))],'videos':video_map.get(i,[])})
meta={'source':'Google Drive ep4_assets_v17.zip','scope':'asset library adopted; current preview remains the 73.13-second opening, not the full episode','image_count':len(list(DST.rglob('*.png'))),'video_count':len(list(DST.glob('*.mp4'))),'chapter_map':chapters,'heroine_images':[str(f.relative_to(DST)) for f in sorted((DST/'heroine').glob('*.png'))],'naming_note':'The mara_* filenames are retained as source filenames. Story text and subtitles keep the supplied novel character name Elena.','video_policy':{'mute_source_audio':True,'playback_rate':1,'duration_seconds':10,'respect_original_fps':24},'review_notes':['ch08-arrest.png shows a dark-haired male subject; do not label this picture as Chloe being arrested, or use it as an exact Julian identity match. Keep as generic illustrative B-roll pending shot selection.','The supplied photos have mixed portrait/landscape framing; use contain or intentional crops preserving faces, never stretch.']}
(P/'assets_v17_catalog.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
f=P/'src/NoirDiary.tsx';s=f.read_text().replace('AbsoluteFill, Html5Audio, Img, interpolate, staticFile, useCurrentFrame','AbsoluteFill, Html5Audio, Html5Video, OffthreadVideo, Sequence, getRemotionEnvironment, Img, interpolate, staticFile, useCurrentFrame')
a=s.index('const FilmImage:');b=s.index('const Small:',a)
replacement=r'''const FilmImage:React.FC<{src:string,video?:boolean,close?:boolean,warm?:boolean,at:number}> = ({src,video=false,close=false,warm=false,at})=>{
 const t=useCurrentFrame()/30;const drift=interpolate(t,[at,at+18],[1.005,1.045],clamp);
 const VideoLayer=getRemotionEnvironment().isRendering?OffthreadVideo:Html5Video;
 const style:React.CSSProperties={width:'100%',height:'100%',objectFit:'cover',objectPosition:close?'18% 37%':warm?'50% 42%':'50% 43%',transform:video?'none':`scale(${close?2.12:drift})`,transformOrigin:close?'18% 37%':'50% 45%',filter:warm?'saturate(.75) contrast(1.04) brightness(.86)':'saturate(.70) contrast(1.05) brightness(.90)'};
 return <AbsoluteFill style={{overflow:'hidden',top:76,bottom:140,height:'auto'}}>
   {video?<div style={{position:'absolute',inset:0}}><Sequence from={Math.round(at*30)} durationInFrames={300} layout="none"><div style={{position:'absolute',inset:0}}><VideoLayer src={staticFile(src)} muted style={style}/></div></Sequence></div>:<Img src={staticFile(src)} style={style}/>}
   <AbsoluteFill style={{background:warm?'linear-gradient(90deg,rgba(25,17,12,.28),transparent 50%,rgba(10,11,13,.42)),linear-gradient(0deg,rgba(10,11,13,.85),transparent 48%)':'linear-gradient(90deg,rgba(5,15,22,.12),transparent 55%,rgba(5,11,17,.4)),linear-gradient(0deg,rgba(8,12,17,.9),transparent 55%)'}}/>
 </AbsoluteFill>;
};
'''
s=s[:a]+replacement+s[b:]
old="const close=t>=13.86&&t<27.286;";s=s.replace(old,"const close=false;")
old="{!diary&&<FilmImage src={wedding?'scenes/wedding.png':'scenes/reference.png'} close={close} warm={wedding} at={wedding?59.394:close?13.86:27.286}/>}"
new="""{!diary&&(t<3.626?<FilmImage src="v17/ch01-head.png" at={0}/>:t<13.626?<FilmImage src="v17/delivery.mp4" video at={3.626}/>:t<23.626?<FilmImage src="v17/ch01-hospital-loop.mp4" video at={13.626}/>:t<27.286?<FilmImage src="v17/ch01-corridor.png" at={23.626}/>:t<40.688?<FilmImage src="v17/ch01-codeblue.png" at={27.286}/>:<FilmImage src="v17/ch01-julian-study.png" warm at={59.394}/>)}"""
assert old in s;s=s.replace(old,new)
s=s.replace("staticFile('scenes/elena_lawyer.png')","staticFile('v17/ch02-lawfirm.png')").replace("objectPosition:'23% 42%'","objectPosition:'40% 42%'")
f.write_text(s)
print('V17 assets adopted:',meta['image_count'],'images,',meta['video_count'],'videos; preview source updated')
