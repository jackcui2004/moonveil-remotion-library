import pathlib,json,re,subprocess
P=pathlib.Path(__file__).resolve().parents[1];A=P/'audio';PUB=P/'public';timing=json.loads((A/'sample_timing.json').read_text());end=timing['duration'];segs={s['id']:s for s in timing['segments']}
def word(seg,text):
 k=re.sub('[^a-z0-9]','',text.lower());return next(w['start'] for w in segs[seg]['words'] if re.sub('[^a-z0-9]','',w['text'].lower())==k)
# Only information events; no whoosh on the female portrait and no artificial electronic beeps.
events=[{'at':segs['s01']['start']-.15,'gain':.55,'reason':'hospital picture panel'},
 {'at':7.9,'gain':.40,'reason':'cardiac monitor information card'},
 {'at':segs['s03']['start']+4.6,'gain':.38,'reason':'blood-loss information card'},
 {'at':word('s04','twenty-six'),'gain':.40,'reason':'age typography'},
 {'at':word('s04','New')-.9,'gain':.38,'reason':'personnel file'},
 {'at':word('s05','Julian'),'gain':.20,'reason':'name label'}]
source=PUB/'sfx/ep3/popup_reference.wav';cmd=['ffmpeg','-y','-v','error','-i',str(A/'voice_full.wav')];fs=['[0:a]anull[voice]'];labels=['[voice]']
for i,e in enumerate(events):
 cmd+=['-i',str(source)];fs.append(f'[{i+1}:a]volume={e["gain"]},adelay={round(e["at"]*1000)}:all=1[fx{i}]');labels.append(f'[fx{i}]')
fs.append(''.join(labels)+f'amix=inputs={len(labels)}:duration=first:normalize=0,alimiter=limit=0.94:level=false:latency=true[out]')
raw=A/'mix_ep3_sfx.wav';subprocess.run(cmd+['-filter_complex',';'.join(fs),'-map','[out]','-t',str(end),'-ar','48000','-ac','1','-c:a','pcm_s16le',str(raw)],check=True)
args=['ffmpeg','-hide_banner','-i',str(raw),'-af','loudnorm=I=-18.6:TP=-0.5:LRA=11:print_format=json','-f','null','-'];r=subprocess.run(args,capture_output=True,text=True,check=True);m=json.JSONDecoder().raw_decode(r.stderr[r.stderr.rfind('{'):])[0]
filt='loudnorm=I=-18.6:TP=-0.5:LRA=11:measured_I='+m['input_i']+':measured_TP='+m['input_tp']+':measured_LRA='+m['input_lra']+':measured_thresh='+m['input_thresh']+':offset='+m['target_offset']+':linear=true'
output=PUB/'full_audio_ep3_sfx.m4a';subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af',filt,'-ar','48000','-ac','1','-c:a','aac','-b:a','160k',str(output)],check=True)
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(output),'-af','loudnorm=I=-18.6:TP=-0.5:LRA=11:print_format=json','-f','null','-'],capture_output=True,text=True,check=True);qc=json.JSONDecoder().raw_decode(r.stderr[r.stderr.rfind('{'):])[0]
meta={'popup_source':'/你的项目路径/EP3工程/full_audio.m4a','extracted_start':3.09,'extracted_duration':.13,'note':'Extracted from the actual EP3 mixed track at the popup immediately before caption onset 3.22s. Original standalone library filename is not available. This is not a claim that its original name was pop_soft_thock.','events':events,'bed':'none in this revision','loudness':qc}
(A/'sfx_reference/ep3_popup_provenance.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));f=P/'src/vox_timeline.json';d=json.loads(f.read_text());d['audio']='full_audio_ep3_sfx.m4a';f.write_text(json.dumps(d,ensure_ascii=False,indent=2));print(json.dumps({'audio':str(output),'events':len(events),'LUFS':qc['input_i'],'true_peak':qc['input_tp'],'duration':end},ensure_ascii=False))
