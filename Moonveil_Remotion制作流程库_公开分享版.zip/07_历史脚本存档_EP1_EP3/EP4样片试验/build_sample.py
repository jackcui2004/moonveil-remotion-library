import pathlib,json,re,subprocess,wave,math,html,shutil
P=pathlib.Path(__file__).resolve().parents[1];A=P/'audio';PUB=P/'public';rows=json.loads((A/'voice_script.json').read_text());timeline=[];cursor=0;mixparts=[]
for row in rows:
 f=A/(row['id']+'.wav');subprocess.run(['ffmpeg','-y','-v','error','-i',str(A/(row['id']+'.mp3')),'-ar','48000','-ac','1','-c:a','pcm_s16le',str(f)],check=True)
 with wave.open(str(f)) as w:dur=w.getnframes()/w.getframerate()
 gap=.65 if row['id']=='chapter-card' else (.75 if row==rows[-1] else .25)
 words=json.loads((A/(row['id']+'.words.json')).read_text());words=[{'text':html.unescape(x['text']),'start':round(cursor+x['start'],5),'end':round(cursor+x['end'],5)} for x in words]
 timeline.append({**row,'start':cursor,'speech_end':cursor+dur,'end':cursor+dur+gap,'words':words});mixparts.append((f,dur,gap));cursor+=dur+gap
frames=math.ceil(cursor*30);end=frames/30
(A/'sample_timing.json').write_text(json.dumps({'duration':end,'frames':frames,'segments':timeline},ensure_ascii=False,indent=2))
# Full original narration with measured pauses, no guessed speech alignment.
filters=[];cmd=['ffmpeg','-y','-v','error']
for i,(f,dur,gap) in enumerate(mixparts):cmd+=['-i',str(f)];filters.append(f'[{i}:a]apad=pad_dur={gap}[v{i}]')
filters.append(''.join(f'[v{i}]' for i in range(len(mixparts)))+f'concat=n={len(mixparts)}:v=0:a=1,apad,atrim=duration={end}[voice]')
subprocess.run(cmd+['-filter_complex',';'.join(filters),'-map','[voice]','-c:a','pcm_s16le',str(A/'voice_full.wav')],check=True)
starts={x['id']:x['start'] for x in timeline}
def when(seg,word):
 word=re.sub('[^a-z0-9]','',word.lower())
 return next((w['start'] for s in timeline if s['id']==seg for w in s['words'] if re.sub('[^a-z0-9]','',w['text'].lower())==word),starts[seg])
first=starts['s01'];s2=starts['s02'];s3=starts['s03'];s4=starts['s04'];s5=starts['s05'];age=when('s04','twenty-six');bar=when('s04','New');julian=when('s05','Julian');don=when('s05','Don')
base=json.loads(pathlib.Path('/你的项目路径/EP3工程/proj/src/vox_timeline.json').read_text())['units'][0]
u={k:[] for k,v in base.items() if isinstance(v,list)}
u.update(id='unit-ep4-opening',start=0,end=end,boardW=4820,kicker='CHAPTER ONE — BLOOD ON THE DELIVERY BED',ghost='I',ghosts=[])
# Hand-planned board: hold centered, move only in short motivated handoffs.
cues=[(0,366,288,1.32),(first,366,288,1.38),(8.4,1026,288,1.25),(s2+.2,1686,288,1.38),(s3+5.5,2346,288,1.26),(s4,3006,288,1.38),(bar-.1,3666,288,1.26),(s5,4326,288,1.38)]
camera=[];previous=cues[0]
for i,(at,cx,cy,scale) in enumerate(cues):
 if i and (cx,cy)!=(previous[1],previous[2]):
  camera.append([round(max(previous[0]+.01,at-1.1),4),previous[3],previous[1],previous[2]])
 camera.append([round(at,4),scale,cx,cy]);previous=(at,cx,cy,scale)
camera.append([end,previous[3],previous[1],previous[2]]);u['camera']=camera
u['panels']=[
 {'src':'scenes/reference.png','scene':'hospital','chapter':1,'side':'L','x':64,'y':118,'w':604,'rot':-1.3,'start':max(0,first-.25),'end':end,'fullbleed':False,'video':None,'video_dur':None,'shake':None,'imageScale':1,'imageOrigin':'50% 50%'},
 {'src':'scenes/reference.png','scene':'elena-close','chapter':1,'side':'L','x':1384,'y':118,'w':604,'rot':1.1,'start':s2-1.05,'end':end,'fullbleed':False,'video':None,'video_dur':None,'shake':None,'imageScale':2.4,'imageOrigin':'18% 37%'},
 {'src':'scenes/elena_lawyer.png','scene':'lawyer','chapter':1,'side':'R','x':2704,'y':118,'w':604,'rot':-1,'start':s4-1.05,'end':end,'fullbleed':False,'video':None,'video_dur':None,'shake':None,'imageScale':1,'imageOrigin':'50% 50%'},
 {'src':'scenes/wedding.png','scene':'marriage','chapter':1,'side':'R','x':4024,'y':118,'w':604,'rot':1.1,'start':s5-1.05,'end':end,'fullbleed':False,'video':None,'video_dur':None,'shake':None,'imageScale':1,'imageOrigin':'50% 50%'}]
u['devices']=[{'type':'clinical','title':'CARDIAC MONITOR','at':7.8,'out':end,'x':724,'y':118,'scale':1,'mode':'ecg'},
 {'type':'clinical','title':'BLOOD LOSS','at':s3+4.5,'out':end,'x':2044,'y':118,'scale':1,'mode':'crisis'},
 {'type':'dossier','title':'ELENA — SEVEN YEARS EARLIER','at':bar-1.1,'out':end,'x':3364,'y':118,'scale':1,'mode':'dossier'}]
u['tags']=[{'text':'MOUNT SINAI — NEW YORK','x':84,'y':440,'at':when('s01','Mount'),'outAt':8.0},
 {'text':'SEVEN YEARS EARLIER','x':2724,'y':440,'at':s4+.15,'outAt':bar-.5},
 {'text':'JULIAN DELUCA — MY HUSBAND','x':4044,'y':440,'at':julian,'outAt':end-1},
 {'text':'DON VINCENT DELUCA · LONG ISLAND','x':4044,'y':490,'at':don,'outAt':end-1}]
u['slams']=[{'big':'26','sub':'JUNIOR ATTORNEY','at':age,'dur':max(2,bar-age-.4),'cross':None,'x':3120,'y':125}]
u['chapter_cards']=[{'chapter':1,'kicker':'CHAPTER ONE','title':'Blood on the Delivery Bed','start':0,'end':first-.1}]
u['captions']=[];keywords={'cardiac','monitor','sinai','shock','blood','seven','twentysix','attorney','bar','deluca','safety','devotion','respect','julian','vincent','five','families'}
for seg in timeline[1:]:
 words=seg['words'];groups=[];group=[]
 for w in words:
  group.append(w)
  if len(group)>=9 or (len(group)>=5 and re.search('[,.;!?]$',w['text'])):groups.append(group);group=[]
 if group:groups.append(group)
 for i,g in enumerate(groups):
  stop=groups[i+1][0]['start'] if i+1<len(groups) else min(seg['end']-.05,g[-1]['end']+.23)
  text=' '.join(x['text'] for x in g);keys=[re.sub("[^a-z0-9']",'',x['text'].lower()) for x in g if re.sub('[^a-z0-9]','',x['text'].lower()) in keywords]
  u['captions'].append({'start':g[0]['start'],'end':stop,'text':text,'keys':keys,'words':g,'chapter':1})
(P/'src/vox_timeline.json').write_text(json.dumps({'fps':30,'width':1920,'height':1080,'audio':'full_audio.m4a','scope':'opening-sample','units':[u]},ensure_ascii=False,indent=2))
# Semantic UI sounds, never a sound on a person appearing.
events=[(.18,'sfx/pop_pluck_1.wav',.16),(first-.2,'sfx/pop_pluck_1.wav',.16),(7.9,'sfx/tap_select_1.wav',.16),(s3+4.6,'sfx/tick_low_bong.wav',.12),(s4-1.05,'sfx/air_swish.wav',.10),(age,'sfx/pop_pluck_1.wav',.14),(bar-.9,'sfx/tap_select_1.wav',.15),(julian,'sfx/tap_select_1.wav',.14)]
cmd=['ffmpeg','-y','-v','error','-i',str(A/'voice_full.wav'),'-stream_loop','-1','-i',str(PUB/'bed.wav')]
filters=['[0:a]volume=1[v]','[1:a]volume=0.055,afade=t=in:d=1.5,afade=t=out:st='+str(end-1.1)+':d=1.1[bed]'];labels=['[v]','[bed]']
for i,(at,file,vol) in enumerate(events):
 cmd+=['-i',str(PUB/file)];filters.append(f'[{i+2}:a]volume={vol},adelay={round(at*1000)}:all=1[fx{i}]');labels.append(f'[fx{i}]')
filters.append(''.join(labels)+f'amix=inputs={len(labels)}:normalize=0:duration=first,alimiter=limit=0.94:level=false:latency=true[raw]')
subprocess.run(cmd+['-filter_complex',';'.join(filters),'-map','[raw]','-ar','48000','-ac','1','-t',str(end),'-c:a','pcm_s16le',str(A/'mix_raw.wav')],check=True)
# Two-pass loudness matching for this new mix.
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(A/'mix_raw.wav'),'-af','loudnorm=I=-18.6:TP=-0.5:LRA=11:print_format=json','-f','null','-'],capture_output=True,text=True,check=True);measure=json.JSONDecoder().raw_decode(r.stderr[r.stderr.rfind('{'):])[0];(A/'loudness_measurement.json').write_text(json.dumps(measure,indent=2));filt='loudnorm=I=-18.6:TP=-0.5:LRA=11:measured_I='+measure['input_i']+':measured_TP='+measure['input_tp']+':measured_LRA='+measure['input_lra']+':measured_thresh='+measure['input_thresh']+':offset='+measure['target_offset']+':linear=true'
subprocess.run(['ffmpeg','-y','-v','error','-i',str(A/'mix_raw.wav'),'-af',filt,'-ar','48000','-ac','1','-c:a','aac','-b:a','160k',str(PUB/'full_audio.m4a')],check=True)
# EP3 component adaptations are local to this sample.
f=P/'src/VoxEpisode.tsx';s=f.read_text();s=s.replace('imgPos?: string; videoSrc?: string;','imgPos?: string; imageScale?: number; imageOrigin?: string; videoSrc?: string;').replace('children }) => {','children, imageScale = 1, imageOrigin = "50% 50%" }) => {',1)
s=s.replace('objectPosition: imgPos ?? "50% 50%" }} />','objectPosition: imgPos ?? "50% 50%", transform: `scale(${imageScale})`, transformOrigin: imageOrigin }} />',1)
s=s.replace('videoDur={p.video_dur ?? undefined} shakeAt={p.shake ?? undefined}','videoDur={p.video_dur ?? undefined} imageScale={p.imageScale ?? 1} imageOrigin={p.imageOrigin ?? "50% 50%"} shakeAt={p.shake ?? undefined}')
s=s.replace('t >= x.start - 0.12 && t <= x.end + 0.05','t >= x.start && t < x.end')
s=s.replace('const current = elapsed >= wStart && elapsed < wEnd;','const boundary = s.words?.[i];\n    const current = boundary ? t >= boundary.start && t < boundary.end : elapsed >= wStart && elapsed < wEnd;')
s=s.replace('const isLast = unit.end > 6036;','const isLast = unit.id === "unit-ep4-opening";')
s=s.replace('{d.type === "map" ? <MapDevice d={d} />','{d.type === "clinical" ? <ClinicalDevice d={d} />\n                  : d.type === "dossier" ? <DossierDevice d={d} />\n                  : d.type === "map" ? <MapDevice d={d} />')
# Model-generated text/illustrations are stills; no fake "video playback" is claimed.
extra=r'''
const ClinicalDevice: React.FC<{d:any}> = ({d}) => {
 const t=useCurrentFrame()/30;const p=usePop(d.at);if(t<d.at)return null;
 const points:number[][]=[];const beat=[[0,0],[.1,0],[.15,-.12],[.19,.16],[.22,-.88],[.25,.49],[.29,0],[.43,-.08],[.5,0],[1,0]];
 for(let i=0;i<5;i++)for(const [x,y] of beat)points.push([20+(i+x)*106,164+y*57]);
 const x=20+((t-d.at)*90)%530;
 return <div style={{width:604,height:340,padding:28,boxSizing:'border-box',border:`2px solid ${GOLD}`,background:'#171713',boxShadow:'0 22px 34px #0008',opacity:Math.min(1,p*1.5),transform:`translateY(${(1-p)*24}px)`}}>
 <div style={{fontFamily:DISPLAY,fontSize:19,fontWeight:800,letterSpacing:3,color:GOLD}}>{d.mode==='ecg'?'MOUNT SINAI / OBSTETRICS':'THE DELIVERY ROOM'}</div>
 <div style={{fontFamily:SERIF,fontSize:d.mode==='ecg'?34:43,fontWeight:700,color:IVORY,marginTop:9}}>{d.title}</div>
 <svg viewBox="0 0 570 205" style={{width:'100%',height:195}}><defs><pattern id={'grid'+d.x} width="22" height="22" patternUnits="userSpaceOnUse"><path d="M 22 0 L 0 0 0 22" fill="none" stroke="#42362b" strokeWidth=".6"/></pattern></defs><rect width="570" height="205" fill={`url(#grid${d.x})`}/><polyline points={points.map(a=>a.join(',')).join(' ')} transform="translate(0 -50)" fill="none" stroke={d.mode==='ecg'?GOLD:CRIMSON_BRIGHT} strokeWidth="2.5"/><line x1={x} y1="30" x2={x} y2="172" stroke={IVORY} strokeWidth="1" opacity=".4"/><text x="22" y="185" fill={d.mode==='ecg'?GOLD:CRIMSON_BRIGHT} fontFamily="Arial" fontSize="17" letterSpacing="3">{d.mode==='ecg'?'CARDIAC MONITOR':'CATASTROPHIC SHOCK'}</text></svg></div>
};
const DossierDevice: React.FC<{d:any}> = ({d}) => {
 const t=useCurrentFrame()/30;const p=usePop(d.at);if(t<d.at)return null;
 const lines=['AGE 26','JUNIOR DEFENSE ATTORNEY','NEW YORK STATE BAR — PASSED'];
 return <div style={{width:604,height:340,boxSizing:'border-box',padding:'30px 34px',background:IVORY,color:'#261e14',transform:`translateY(${(1-p)*30}px) rotate(-.7deg)`,opacity:Math.min(1,p*1.5),boxShadow:'0 20px 32px #0008'}}><div style={{fontFamily:DISPLAY,color:CRIMSON,fontSize:18,letterSpacing:3,fontWeight:800}}>PERSONNEL FILE / NEW YORK</div><div style={{fontFamily:SERIF,fontWeight:700,fontSize:43,marginTop:6,marginBottom:13}}>Elena</div>{lines.map((x,i)=><div key={i} style={{fontFamily:SANS,fontSize:22,fontWeight:600,borderBottom:'1px solid #b4a990',padding:'10px 0',opacity:Math.max(0,Math.min(1,(t-d.at-i*.45)/.4))}}>{x}</div>)}</div>
};
'''
s=s.replace('// ---------- main ----------',extra+'\n// ---------- main ----------');f.write_text(s)
(P/'src/Root.tsx').write_text('import React from "react";\nimport {Composition} from "remotion";\nimport {VoxEpisode} from "./VoxEpisode";\nexport const Root:React.FC=()=> <Composition id="preview-ep4" component={VoxEpisode} fps={30} width={1920} height={1080} durationInFrames={'+str(frames)+'} defaultProps={{unitId:"unit-ep4-opening"}}/>;\n')
# Write a readable shot plan before preview/render.
plan=['# EP4 开头样片编排','',f'长度：{end:.3f} 秒，{frames} 帧。原文165词＋章节卡。人物视频按用户要求暂用图片。','', '| 时间 | 视觉主体 | 任务 |','|---|---|---|']
for at,cx,cy,scale in cues:plan.append(f'| {at:.2f}s | 板面中心 {cx} | 镜头保持；交接前1.1秒才移动 |')
plan+=['','## 资产来源','- 原始医院图：用户附件。','- 律师与婚姻回忆图：imagegen，以附件为人物身份参考。','- 组件：EP3 VoxEpisode，新增心电装置与身份档案；没有借用旧集人物/剧情图。','- 配音：Ava Multilingual；字幕使用实际 WordBoundary。','- UI sounds by Little Robot Sound Factory — www.littlerobotsoundfactory.com']
(P/'SHOT_PLAN.md').write_text('\n'.join(plan)+'\n');(P/'generation_prompts.txt').write_text('律师画面：以用户医院图中的女主为身份锚，26岁健康漂亮的新晋纽约辩护律师，炭灰西装与象牙衬衣，曼哈顿法院走廊、真实电影照片。\n婚姻回忆：以同图女主与金发男主为身份锚，象牙婚纱与炭灰礼服，长岛老钱庄园冬夜，真实电影照片；无额外人物、文字、水印。\n工具：内置 imagegen。\n')
print(json.dumps({'seconds':end,'frames':frames,'segments':[(x['id'],round(x['start'],3),round(x['speech_end'],3)) for x in timeline],'keywords':{'age':age,'bar':bar,'julian':julian,'don':don}},ensure_ascii=False))
