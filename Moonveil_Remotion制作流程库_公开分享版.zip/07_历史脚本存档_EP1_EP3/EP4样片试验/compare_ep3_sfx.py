import pathlib,subprocess,numpy as np,json
P=pathlib.Path(__file__).resolve().parents[1];O=P/'audio/sfx_reference';O.mkdir(exist_ok=True);rate=16000

def load(f,duration=None):
 cmd=['ffmpeg','-v','error','-i',str(f)]
 if duration:cmd+=['-t',str(duration)]
 cmd+=['-ar',str(rate),'-ac','1','-f','f32le','-']
 return np.frombuffer(subprocess.run(cmd,capture_output=True,check=True).stdout,np.float32).astype(np.float64)
y=load('/你的项目路径/EP3工程/full_audio.m4a',90)
new=load(P/'public/full_audio.m4a',73)
result=[]
for f in sorted((P/'public/sfx').glob('*.wav')):
 x=load(f);active=np.where(np.abs(x)>max(np.max(np.abs(x))*.008,.0001))[0]
 if not len(active):continue
 lo=max(0,int(active[0])-10);hi=min(len(x),int(active[-1])+11);x=x[lo:hi];x=x-x.mean();N=len(x)
 def scan(y):
  n=1<<(len(y)+N-2).bit_length();corr=np.fft.irfft(np.fft.rfft(y,n)*np.fft.rfft(x[::-1],n),n)[N-1:len(y)]
  cs=np.concatenate(([0.],np.cumsum(y*y)));energy=cs[N:]-cs[:-N];xn=np.dot(x,x);score=np.where(energy>1e-4,corr/np.sqrt(np.maximum(energy*xn,1e-16)),0)
  hits=[];work=score.copy()
  for _ in range(5):
   i=int(np.argmax(work));at=(i-lo)/rate
   hits.append({'time':round(at,4),'correlation':round(float(score[i]),4),'estimated_gain':round(float(corr[i]/xn),5)})
   work[max(0,i-int(.18*rate)):i+int(.18*rate)]=0
  return hits
 result.append({'asset':f.name,'ep3':scan(y),'ep4':scan(new)})
(O/'comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
