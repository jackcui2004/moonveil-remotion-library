import asyncio,json,pathlib,subprocess,edge_tts
P=pathlib.Path(__file__).resolve().parents[1];rows=json.loads((P/'audio/voice_script.json').read_text())
async def one(row):
 path=P/'audio'/(row['id']+'.mp3');words=[]
 try:
  c=edge_tts.Communicate(row['text'],voice='en-US-AvaMultilingualNeural',boundary='WordBoundary',connect_timeout=10,receive_timeout=30)
  with path.open('wb') as f:
   async for event in c.stream():
    if event['type']=='audio':f.write(event['data'])
    elif event['type']=='WordBoundary':words.append({'text':event['text'],'start':event['offset']/1e7,'end':(event['offset']+event['duration'])/1e7})
  d=float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(path)],capture_output=True,text=True,check=True).stdout.strip())
  (P/'audio'/(row['id']+'.words.json')).write_text(json.dumps(words,ensure_ascii=False,indent=2));print(row['id'],'OK',round(d,2),'seconds',len(words),'words',flush=True);return {'id':row['id'],'duration':d,'words':len(words)}
 except Exception as e:print(row['id'],'FAILED',type(e).__name__,str(e),flush=True);raise
async def main():
 r=await asyncio.gather(*(one(row) for row in rows));(P/'audio/durations.json').write_text(json.dumps(r,indent=2))
asyncio.run(main())
