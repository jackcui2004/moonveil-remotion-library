#!/usr/bin/env python3
"""Chunked resumable Remotion queue: story units (dur>90s) render in 60s
frame-range slices of the SAME composition (identical pixels), then concat.
A failed slice retries alone; slice files persist for resume. Host units
render whole, as before. Falls back to whole-unit render if concat invalid."""
import json, os, subprocess, sys, time

WS = os.path.dirname(os.path.abspath(__file__))
PROJ = f"{WS}/proj"
UNITS_DIR = f"{WS}/units"
CHUNKS = f"{WS}/units/chunks"
LOGS = f"{WS}/logs"
for d in (UNITS_DIR, CHUNKS, LOGS):
    os.makedirs(d, exist_ok=True)

manifest = {m["id"]: m for m in json.load(open(f"{WS}/manifest.json"))}
ORDER = [m["id"] for m in json.load(open(f"{WS}/manifest.json"))]
FPS = 30
SLICE = 1800  # 60 s

def probe_dur(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", path], capture_output=True, text=True)
    try:
        return float(r.stdout.strip())
    except Exception:
        return None

def valid(uid):
    p = f"{UNITS_DIR}/{uid}.mp4"
    if not os.path.exists(p) or os.path.getsize(p) < 10000:
        return False
    d = probe_dur(p)
    return d is not None and abs(d - manifest[uid]["dur"]) <= 0.15

def remotion(uid, out, conc, frames=None, logname=None):
    cmd = ["./node_modules/.bin/remotion", "render", "src/index.ts", uid.replace("_", "-"), out,
           f"--concurrency={conc}", "--muted", "--image-format=jpeg", "--jpeg-quality=85",
           "--log=info", "--browser-executable=/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    if frames:
        cmd.append(f"--frames={frames[0]}-{frames[1]}")
    with open(f"{LOGS}/{logname or ('render_' + uid + '.log')}", "w") as lf:
        r = subprocess.run(cmd, cwd=PROJ, stdout=lf, stderr=subprocess.STDOUT)
    return r.returncode == 0

def render_whole(uid, conc):
    out = f"{UNITS_DIR}/{uid}.mp4"
    t0 = time.time()
    ok = remotion(uid, out, conc) and valid(uid)
    print(f"{uid}: {'OK' if ok else 'FAIL'} whole render {time.time()-t0:.0f}s "
          f"dur={probe_dur(out)} target={manifest[uid]['dur']}", flush=True)
    return ok

def slice_ok(path, frames):
    if not os.path.exists(path) or os.path.getsize(path) < 10000:
        return False
    d = probe_dur(path)
    return d is not None and abs(d - frames / FPS) <= 0.2

def render_chunked(uid, conc):
    total = round(manifest[uid]["dur"] * FPS)
    spans = []
    s = 0
    while s < total:
        e = min(s + SLICE - 1, total - 1)
        spans.append((s, e))
        s = e + 1
    parts = []
    for i, (a, b) in enumerate(spans):
        part = f"{CHUNKS}/{uid}_{i:02d}.mp4"
        parts.append(part)
        if slice_ok(part, b - a + 1):
            print(f"{uid}[{i}]: skip slice (valid)", flush=True)
            continue
        ok = False
        for attempt in range(3):
            if attempt:
                time.sleep(15)
            t0 = time.time()
            if remotion(uid, part, conc, frames=(a, b), logname=f"render_{uid}_s{i:02d}.log") \
               and slice_ok(part, b - a + 1):
                print(f"{uid}[{i}]: OK slice {time.time()-t0:.0f}s frames {a}-{b}", flush=True)
                ok = True
                break
            print(f"{uid}[{i}]: slice attempt {attempt+1} failed", flush=True)
        if not ok:
            print(f"{uid}: slice {i} GAVE UP -> whole-render fallback", flush=True)
            return render_whole(uid, conc)
    lst = f"{CHUNKS}/{uid}_concat.txt"
    with open(lst, "w") as f:
        for p in parts:
            f.write(f"file '{p}'\n")
    out = f"{UNITS_DIR}/{uid}.mp4"
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
                        "-i", lst, "-c", "copy", out], capture_output=True, text=True)
    if r.returncode == 0 and valid(uid):
        print(f"{uid}: OK chunked ({len(parts)} slices) dur={probe_dur(out)} "
              f"target={manifest[uid]['dur']}", flush=True)
        return True
    print(f"{uid}: concat invalid -> whole-render fallback", flush=True)
    return render_whole(uid, conc)

def render_unit(uid, conc):
    if valid(uid):
        print(f"{uid}: skip (already valid)", flush=True)
        return True
    if manifest[uid]["dur"] > 90:
        ok = render_chunked(uid, conc)
    else:
        ok = False
        for attempt in range(3):
            if attempt:
                time.sleep(20)
            ok = render_whole(uid, conc)
            if ok:
                break
    if not ok:
        print(f"{uid}: GAVE UP", flush=True)
    return ok

if __name__ == "__main__":
    from concurrent.futures import ThreadPoolExecutor, as_completed
    conc = os.environ.get("CONC", "2")
    workers = max(1, int(os.environ.get("JOBS", "3")))
    ids = list(dict.fromkeys(sys.argv[1:] or ORDER))
    print(f"Parallel units: {workers}; concurrency per unit: {conc}", flush=True)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(render_unit, uid, conc): uid for uid in ids}
        for future in as_completed(futures):
            uid = futures[future]
            try:
                future.result()
            except Exception as exc:
                print(f"{uid}: ERROR {exc}", flush=True)
    done = sum(1 for u in ORDER if valid(u))
    print(f"VALID {done}/{len(ORDER)}")
