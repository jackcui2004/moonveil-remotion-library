# Moonveil Vox 工程 · Mac 本地渲染说明

这是一个完整的 Remotion 工程 + 渲染队列脚本。已经渲好的单元都在 units/ 里，
脚本会自动跳过，只渲剩下的。Mac 上渲完后把新出的 units/*.mp4 传回
Google Drive 的 Moonveil 文件夹，云端这边负责总装成片。

## 一次性准备（约 10 分钟）

1. 装 Node.js LTS（选 macOS Apple Silicon 版）：
   https://nodejs.org
2. 装 ffmpeg（队列拼接切片要用）：
   - 先装 Homebrew（终端粘贴官网命令）：https://brew.sh
   - 然后：brew install ffmpeg
3. 解压本包，进到 proj 文件夹装依赖（会自动下载 Mac 版渲染组件，
   含无头 Chrome，约 1–3 分钟，需要联网）：
   cd full_episode_vox_v1/proj
   npm install

## 开始渲染

回到工程根目录，跑队列（单元列表按故事顺序，脚本自动跳过已完成的）：

cd ../
CONC=3 python3 -u render_queue2.py INTRO ANN_01 NAR_01 ANN_02 NAR_02 ANN_03 NAR_03 ANN_04 NAR_04 ANN_05 NAR_05 ANN_06 NAR_06 ANN_07 NAR_07 R1 ANN_08 NAR_08 ANN_09 NAR_09 ANN_10 NAR_10 ANN_11 NAR_11 ANN_12 NAR_12 R2 ANN_13 NAR_13 ANN_14 NAR_14 ANN_15 NAR_15 ANN_16 NAR_16 ANN_17 NAR_17 ANN_18 NAR_18 R3 ANN_19 NAR_19 ANN_20 NAR_20 EPI OUTRO

- 16GB 内存可以 CONC=3；如果风扇狂转或内存吃紧，改 CONC=2 也行。
- 渲染时请插电，并让命令防休眠：把整条命令前面加上 caffeinate -i
  （例：caffeinate -i python3 -u render_queue2.py ...）
- 中断了直接重跑同一条命令即可，已完成的切片和单元都会跳过，不会重渲。

## 交回

把 units/ 里新生成的 .mp4 文件上传到 Google Drive 的 Moonveil 文件夹，
告诉 Muse 一声，就在这边拼成完整一集。
