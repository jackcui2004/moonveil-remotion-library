import json, pathlib, subprocess, re, concurrent.futures, math
P=pathlib.Path(__file__).resolve().parent
SRC=pathlib.Path('/你的用户目录/Desktop/哈吉米/10.30 那一刀，是我能给你的最后一点温柔 - 九死其犹未悔/1/1.mp3')
PUB=P/'proj/public'; OUT=P/'audio_aligned'; OUT.mkdir(exist_ok=True)
manifest=json.loads((P/'manifest.json').read_text()); matches=json.loads((P/'audio_sentence_alignment.json').read_text())
def run(cmd,log):
 with open(OUT/log,'w') as f: subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
def tempo(x):
 fs=[]
 while x>2: fs.append('atempo=2');x/=2
 fs.append(f'atempo={x:.8f}');return ','.join(fs)
def make(m):
 uid=m['id']; dur=m['frames']/30; output=OUT/(uid+'.wav')
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-threads','2']
 if m['kind']=='story':
  rows=[x for x in matches if x['unit']==uid];base=max(0,rows[0]['src_start']-.06)
  end=rows[-1]['src_end']+.2;cmd+=['-ss',str(base),'-t',str(end-base),'-i',str(SRC)]
  filters=[];labels=[];cursor=0
  for j,x in enumerate(rows):
   if x['dst_start']>cursor+.0001:
    lab=f'g{j}';filters.append(f'anullsrc=r=48000:cl=mono,atrim=duration={x["dst_start"]-cursor:.8f}[{lab}]');labels.append(f'[{lab}]')
   start=max(base,x['src_start']-.035)
   if j: start=max(start,rows[j-1]['src_end'])
   stop=(rows[j+1]['src_start']-.035 if j+1<len(rows) else x['src_end']+.15)
   stop=max(stop,x['src_end']);stop=min(stop,end)
   if stop<=start: start=max(base,start-.08);stop=start+.16
   target=x['dst_end']-x['dst_start'];rate=max(1,(stop-start)/target)
   lab=f's{j}'; filters.append(f'[0:a]atrim=start={start-base:.8f}:end={stop-base:.8f},asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=mono,{tempo(rate)},apad,atrim=duration={target:.8f},afade=t=in:d=0.003,afade=t=out:st={max(0,target-.006):.8f}:d=0.006[{lab}]');labels.append(f'[{lab}]');cursor=x['dst_end']
  if dur>cursor:
   filters.append(f'anullsrc=r=48000:cl=mono,atrim=duration={dur-cursor:.8f}[tail]');labels.append('[tail]')
  filters.append(''.join(labels)+f'concat=n={len(labels)}:v=0:a=1,apad,atrim=duration={dur:.8f}[out]')
  graph=OUT/(uid+'.filter');graph.write_text(';\n'.join(filters));cmd+=['-filter_complex',graph.read_text(),'-map','[out]']
 elif uid in ['INTRO','ANN_01']:
  start=0 if uid=='INTRO' else 38.584
  cmd+=['-ss',str(start),'-i',str(PUB/'narration.wav'),'-af',f'aresample=48000,aformat=channel_layouts=mono,apad,atrim=duration={dur:.8f}']
 else:
  cmd+=['-f','lavfi','-i','anullsrc=r=48000:cl=mono','-t',str(dur)]
 cmd+=['-ar','48000','-ac','1','-c:a','pcm_s16le',str(output)];run(cmd,uid+'.log');print(uid,'audio ready',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(make,manifest))
(OUT/'concat.txt').write_text(''.join("file '"+str(OUT/(m['id']+'.wav'))+"'\n" for m in manifest))
run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(OUT/'concat.txt'),'-c','copy',str(OUT/'narration_aligned.wav')],'concat.log')
sfx=re.findall(r'\[([\d.]+), "(sfx/[^\"]+)", ([\d.]+)\]',(P/'proj/src/data.ts').read_text())
cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(P/'Moonveil_完整画面版.mp4'),'-i',str(OUT/'narration_aligned.wav'),'-i',str(PUB/'bed.wav')]
filters=['[1:a]aresample=48000[a0]','[2:a]atrim=duration=57.51,asetpts=PTS-STARTPTS,volume=0.1,afade=t=out:st=56.5:d=1.01[a1]'];labs=['[a0]','[a1]']
for i,(at,file,vol) in enumerate(sfx):
 cmd+=['-i',str(PUB/file)];lab=f'a{i+2}';filters.append(f'[{i+3}:a]atrim=duration=3.2,asetpts=PTS-STARTPTS,volume={vol},adelay={round(float(at)*1000)}:all=1[{lab}]');labs.append(f'[{lab}]')
filters.append(''.join(labs)+f'amix=inputs={len(labs)}:duration=first:normalize=0,alimiter=limit=0.95:level=false:latency=true[out]')
(OUT/'mix.filter').write_text(';\n'.join(filters))
cmd+=['-filter_complex',(OUT/'mix.filter').read_text(),'-map','0:v:0','-map','[out]','-c:v','copy','-c:a','aac','-b:a','192k','-movflags','+faststart',str(P/'Moonveil_完整配音版.mp4')]
run(cmd,'mix.log');print('FULL MIX READY',flush=True)
