#!/bin/bash
# Moonveil 第3集 — Mac 端总装：校验单元齐全 → 拼接（无重编码）→ 合入最终音轨 → 报告时长。
# 用法：渲染完成后，在本包目录下运行：bash assemble_mac.sh
set -u
cd "$(dirname "$0")"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

UNITS="unit-ep3-ch01 unit-ep3-ch02 unit-ep3-ch03 unit-ep3-ch04 unit-ep3-ch05 unit-ep3-ch06 unit-ep3-ch07 unit-ep3-ch08 unit-ep3-ch09 unit-ep3-ch10"
EXPECTED=5510.60

missing=0
for u in $UNITS; do
  if [ ! -s "proj/out/$u.mp4" ]; then echo "缺少单元: proj/out/$u.mp4"; missing=1; fi
done
if [ "$missing" = "1" ]; then echo "有单元缺失，先跑 python3 render_queue.py 补齐。"; exit 1; fi
if [ ! -f "full_audio.m4a" ]; then echo "缺少 full_audio.m4a（最终音轨）。"; exit 1; fi

LIST=$(mktemp)
for u in $UNITS; do echo "file '$PWD/proj/out/$u.mp4'" >> "$LIST"; done

echo "拼接 10 个单元..."
ffmpeg -y -v error -f concat -safe 0 -i "$LIST" -c copy _video_only.mp4 || { echo "拼接失败"; exit 1; }

DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 _video_only.mp4)
echo "Video duration: ${DUR}s; expected: ${EXPECTED}s"
python3 - "$DUR" "${EXPECTED}" <<'PY' || { echo "时长偏差超过 1 秒，总装中止——把这个输出发给 Muse。"; exit 1; }
import sys
dur, exp = float(sys.argv[1]), float(sys.argv[2])
if abs(dur - exp) > 1.0:
    print(f"偏差 {dur-exp:+.2f}s"); sys.exit(1)
PY

echo "合入最终音轨..."
ffmpeg -y -v error -i _video_only.mp4 -i full_audio.m4a -map 0:v:0 -map 1:a:0 -c copy Moonveil_Ep3_final.mp4 || { echo "合轨失败"; exit 1; }

rm -f "$LIST" _video_only.mp4
echo "=== 完成：Moonveil_Ep3_final.mp4 ==="
ls -la Moonveil_Ep3_final.mp4
ffprobe -v error -show_entries format=duration -of csv=p=0 Moonveil_Ep3_final.mp4
echo "上传 YouTube 时请设定时发布：美东时间 19:00。上传后把链接发给 Muse 补片尾与信息卡。"
