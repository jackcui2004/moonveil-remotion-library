# Moonveil 第 3 集工程包 — Mac 操作说明

本集：《Play The Game Or Leave — My Mafia Groom Mocked As A Chilling Smile Froze My Vengeful Eyes》
成片总长约 **1:31:51**（5510.6 秒，10 章）。渲染在 Mac 上做，单元为静音渲染，最终音轨在总装时合入，这是设计好的流程。

## 一条命令开跑

在本文件夹打开终端，依次执行：

```bash
python3 render_queue.py
bash assemble_mac.sh
```

## 说明

- 前置：Node.js（LTS 版）与 ffmpeg。没有的话先装：`brew install node ffmpeg`。
- `render_queue.py` 首次运行会自动 `npm install`；之后逐章渲染到 `proj/out/`，**中断后重跑会自动跳过已完成的章**，不用重来。全集渲染需要几个小时，插电放着跑即可。
- `assemble_mac.sh` 会先校验 10 个单元和音轨齐不齐、时长对不对（偏差超过 1 秒会停下来报错，不会产出残品），然后拼出 **`Moonveil_Ep3_final.mp4`**。
- 不要改名或移动包内任何文件，脚本按固定名字找文件。

## 上传

把 `Moonveil_Ep3_final.mp4` 上传 YouTube，标题与简介文案在 `upload_description.txt` 里（含章节时间戳），**设定时发布：美东时间 19:00**。上传完把视频链接发给 Muse，它来补片尾屏幕和信息卡。
