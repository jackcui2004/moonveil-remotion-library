#!/usr/bin/env python3
import time, os, subprocess, json, sys

os.environ["PATH"] = "/opt/homebrew/bin:/usr/local/bin:" + os.environ.get("PATH", "")
PROJ = "/你的项目路径/EP3工程/proj"
REMOTION = "/你的项目路径/EP3工程/proj/node_modules/.bin/remotion"
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

# 测试 300 帧 (10 秒视频)
FRAMES = "10000-10299"
N_FRAMES = 300

configs = [
    {
        "name": "1. 默认 Headless Shell (单任务并发=2)",
        "cmd": [REMOTION, "render", "src/index.ts", "unit-ep3-ch01", "/tmp/bench1.mp4",
                f"--frames={FRAMES}", "--concurrency=2", "--muted", "--codec=h264", "--crf=18",
                "--image-format=jpeg", "--jpeg-quality=90", "--overwrite", "--log=warn"]
    },
    {
        "name": "2. 默认 Headless Shell (单任务并发=4)",
        "cmd": [REMOTION, "render", "src/index.ts", "unit-ep3-ch01", "/tmp/bench2.mp4",
                f"--frames={FRAMES}", "--concurrency=4", "--muted", "--codec=h264", "--crf=18",
                "--image-format=jpeg", "--jpeg-quality=90", "--overwrite", "--log=warn"]
    },
    {
        "name": "3. 默认 Headless Shell (单任务并发=6)",
        "cmd": [REMOTION, "render", "src/index.ts", "unit-ep3-ch01", "/tmp/bench3.mp4",
                f"--frames={FRAMES}", "--concurrency=6", "--muted", "--codec=h264", "--crf=18",
                "--image-format=jpeg", "--jpeg-quality=90", "--overwrite", "--log=warn"]
    },
    {
        "name": "4. 系统 Chrome + GPU Metal/ANGLE (并发=4)",
        "cmd": [REMOTION, "render", "src/index.ts", "unit-ep3-ch01", "/tmp/bench4.mp4",
                f"--frames={FRAMES}", "--concurrency=4", "--muted", "--codec=h264", "--crf=18",
                "--image-format=jpeg", "--jpeg-quality=90", f"--browser-executable={CHROME}",
                "--gl=angle", "--overwrite", "--log=warn"]
    },
    {
        "name": "5. 系统 Chrome + GPU Metal/ANGLE (并发=6)",
        "cmd": [REMOTION, "render", "src/index.ts", "unit-ep3-ch01", "/tmp/bench5.mp4",
                f"--frames={FRAMES}", "--concurrency=6", "--muted", "--codec=h264", "--crf=18",
                "--image-format=jpeg", "--jpeg-quality=90", f"--browser-executable={CHROME}",
                "--gl=angle", "--overwrite", "--log=warn"]
    },
    {
        "name": "6. 系统 Chrome + GPU Metal/ANGLE (并发=8 - 榨干M4算力)",
        "cmd": [REMOTION, "render", "src/index.ts", "unit-ep3-ch01", "/tmp/bench6.mp4",
                f"--frames={FRAMES}", "--concurrency=8", "--muted", "--codec=h264", "--crf=18",
                "--image-format=jpeg", "--jpeg-quality=90", f"--browser-executable={CHROME}",
                "--gl=angle", "--overwrite", "--log=warn"]
    }
]

print("=" * 60)
print(f"🔬 开始测试不同线程/并发配置（每组测试 {N_FRAMES} 帧）...")
print("=" * 60, flush=True)

results = []
for c in configs:
    name = c["name"]
    cmd = c["cmd"]
    print(f"\n▶ 正在测试: {name} ...", flush=True)
    t0 = time.time()
    res = subprocess.run(cmd, cwd=PROJ, capture_output=True, text=True)
    t1 = time.time()
    elapsed = t1 - t0
    if res.returncode == 0:
        fps = N_FRAMES / elapsed
        print(f"  ✓ 耗时: {elapsed:.2f}s | 🚀 渲染速度: {fps:.1f} fps", flush=True)
        results.append((name, fps, elapsed))
    else:
        print(f"  ✗ 失败 (code {res.returncode}): {res.stderr[:200]}", flush=True)

print("\n" + "=" * 60)
print("📊 测试结果排行榜 (从快到慢):")
print("=" * 60)
results.sort(key=lambda x: x[1], reverse=True)
for rank, (name, fps, elapsed) in enumerate(results, 1):
    print(f"#{rank} | {fps:5.1f} fps (耗时 {elapsed:5.2f}s) | {name}")
print("=" * 60, flush=True)
