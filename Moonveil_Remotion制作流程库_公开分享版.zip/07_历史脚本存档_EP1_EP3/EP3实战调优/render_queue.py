#!/usr/bin/env python3
# Moonveil Ep3 — Mac 端渲染队列：按 manifest 顺序逐单元渲染（静音），断点续跑。
# 用法：在本包目录下运行  python3 render_queue.py
import json, os, shutil, subprocess, sys

os.environ["PATH"] = "/opt/homebrew/bin:/usr/local/bin:" + os.environ.get("PATH", "")

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.join(HERE, "proj")
OUT = os.path.join(PROJ, "out")

def die(msg):
    print("错误：" + msg); sys.exit(1)

for tool in ("node", "npx", "ffmpeg"):
    if not shutil.which(tool):
        die(f"未找到 {tool}。请先安装 Node.js LTS 与 ffmpeg（例如：brew install node ffmpeg）。")

man = json.load(open(os.path.join(HERE, "manifest.json")))
units_dict = {u["id"]: u.get("duration_sec", 0) for u in man["units"]}
units = [u["id"] for u in man["units"]]
os.makedirs(OUT, exist_ok=True)

def is_unit_complete(out_file, expected_sec):
    if not os.path.exists(out_file) or os.path.getsize(out_file) < 1_000_000:
        return False
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", out_file],
            capture_output=True, text=True)
        if r.returncode == 0 and r.stdout.strip():
            dur = float(r.stdout.strip())
            return abs(dur - expected_sec) <= 1.5
    except Exception:
        pass
    return False

if not os.path.isdir(os.path.join(PROJ, "node_modules")):
    print("首次运行：安装工程依赖（npm install）...")
    r = subprocess.run(["npm", "install"], cwd=PROJ)
    if r.returncode != 0:
        die("npm install 失败，请检查网络后重跑本脚本。")

for i, uid in enumerate(units, 1):
    out_file = os.path.join(OUT, uid + ".mp4")
    expected_sec = units_dict.get(uid, 0)
    if is_unit_complete(out_file, expected_sec):
        print(f"[{i}/{len(units)}] 跳过 {uid}（已完整渲染）")
        continue
    elif os.path.exists(out_file):
        print(f"[{i}/{len(units)}] 发现不完整文件 {uid}.mp4，清理后重新渲染...")
        os.remove(out_file)
    print(f"[{i}/{len(units)}] 渲染 {uid} ...", flush=True)
    r = subprocess.run(
        ["npx", "remotion", "render", "src/index.ts", uid, f"out/{uid}.mp4",
         "--muted", "--concurrency=2"],
        cwd=PROJ)
    if r.returncode != 0 or not os.path.exists(out_file):
        die(f"{uid} 渲染失败。修复问题后重跑本脚本即可从断点继续。")

print("全部单元渲染完成。正在自动启动总装脚本 (assemble_mac.sh)...")
r_asm = subprocess.run(["bash", os.path.join(HERE, "assemble_mac.sh")], cwd=HERE)
if r_asm.returncode != 0:
    die("总装 (assemble_mac.sh) 执行失败，请检查上方日志。")
print("恭喜！全流程渲染与总装已全部圆满完成！")
