#!/usr/bin/env python3
"""
Moonveil Ep3 实时渲染进度看板后台服务
提供 / (Web 界面) 和 /api/progress (实时 JSON 接口)
"""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import collections
import json
import os
import pathlib
import re
import sys
import time

P = pathlib.Path(__file__).resolve().parent
PROJ = P / "proj"
OUT = PROJ / "out"
CH = OUT / "chunks"
LOG = P / "render_logs"

man_file = P / "manifest.json"
man = json.loads(man_file.read_text()) if man_file.exists() else {"units": []}
units = man.get("units", [])
total_frames = sum(u.get("frames", 0) for u in units)

# 预构建所有切片清单
SLICE = 1800
all_slices = []
slice_frame_map = {}
for u in units:
    uid = u["id"]
    tf = u["frames"]
    idx = 0
    for a in range(0, tf, SLICE):
        b = min(a + SLICE, tf) - 1
        key = f"{uid}_s{idx:03d}"
        f_count = b - a + 1
        all_slices.append({"key": key, "unit": uid, "frames": f_count})
        slice_frame_map[key] = f_count
        idx += 1

total_slices = len(all_slices)
history = collections.deque(maxlen=90)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/api/progress":
            try:
                progress_file = OUT / "progress.json"
                if not progress_file.exists():
                    d = {
                        "started": time.time(),
                        "total_jobs": total_slices,
                        "completed_jobs": 0,
                        "active_jobs": {}
                    }
                else:
                    d = json.loads(progress_file.read_text())

                now = time.time()
                if getattr(self.server, "render_started", None) != d.get("started"):
                    history.clear()
                    self.server.render_started = d.get("started")
                started = d.get("started", now)
                elapsed = max(0, now - started)

                # 统计已完成切片
                completed_keys = set()
                completed_frames = 0
                if CH.exists():
                    for chunk_file in CH.glob("*.mp4"):
                        if not chunk_file.name.endswith(".partial.mp4") and chunk_file.stat().st_size > 10000:
                            k = chunk_file.stem
                            completed_keys.add(k)
                            completed_frames += slice_frame_map.get(k, SLICE)

                # 收集活跃切片进度
                active_list = []
                partial_frames = 0
                for key, val in d.get("active_jobs", {}).items():
                    log_file = LOG / f"{key}.log"
                    cur_f = 0
                    tot_f = slice_frame_map.get(key, SLICE)
                    if log_file.exists():
                        try:
                            with open(log_file, "rb") as f:
                                f.seek(0, 2)
                                sz = f.tell()
                                f.seek(max(0, sz - 8192))
                                tail = f.read().decode(errors="replace")
                            matches = re.findall(r"Rendered (\d+)/(\d+)", tail)
                            if matches:
                                cur_f = min(int(matches[-1][0]), tot_f)
                        except Exception:
                            pass

                    partial_frames += cur_f
                    job_elapsed = max(0, now - val.get("start", now))
                    active_list.append({
                        "key": key,
                        "current": cur_f,
                        "total": tot_f,
                        "percentage": round(cur_f / tot_f * 100, 1) if tot_f else 0,
                        "elapsed": job_elapsed,
                        "attempt": val.get("attempt", 1)
                    })

                done_frames = completed_frames + partial_frames
                if (P / "Moonveil_Ep3_final.mp4").exists():
                    stage = "complete"
                    done_frames = total_frames
                elif len(completed_keys) == total_slices:
                    stage = "assembling"
                else:
                    stage = "rendering"

                # 测算滑动窗口速度 (最近 30~60 秒的真实渲染帧率)
                history.append((now, done_frames))
                # 寻找 20-60 秒前的基准点
                base = history[0]
                for h_time, h_frames in history:
                    if now - h_time >= 15:
                        base = (h_time, h_frames)
                        break

                delta_t = now - base[0]
                delta_f = done_frames - base[1]
                if delta_t >= 5 and delta_f >= 0:
                    speed = max(0.1, delta_f / delta_t)
                else:
                    speed = None  # 尚未积累足够样本，不虚构初始帧速

                rem_frames = max(0, total_frames - done_frames)
                eta = rem_frames / speed if speed and speed > 0.05 and stage == "rendering" else None

                active_keys = set(x["key"] for x in active_list)
                slices_view = []
                for s in all_slices:
                    k = s["key"]
                    st = "done" if k in completed_keys else ("active" if k in active_keys else "waiting")
                    slices_view.append({"key": k, "status": st})

                res = {
                    "stage": stage,
                    "percentage": round(min(100.0, (done_frames / total_frames * 100)), 1) if total_frames else 0,
                    "done_frames": done_frames,
                    "total_frames": total_frames,
                    "complete_slices": len(completed_keys),
                    "total_slices": total_slices,
                    "elapsed": elapsed,
                    "eta": eta,
                    "speed": round(speed, 1) if speed is not None else None,
                    "active_jobs": active_list,
                    "slices": slices_view,
                    "completed_keys": list(completed_keys),
                    "final": str(P / "Moonveil_Ep3_final.mp4") if (P / "Moonveil_Ep3_final.mp4").exists() else None,
                    "updated": now
                }
                self.send_json(200, res)
            except Exception as e:
                self.send_json(500, {"error": str(e)})
        elif path == "/":
            html_file = P / "render_progress.html"
            if html_file.exists():
                self.send_bytes(200, html_file.read_bytes(), "text/html; charset=utf-8")
            else:
                self.send_bytes(404, b"render_progress.html not found", "text/plain")
        else:
            self.send_bytes(404, b"Not found", "text/plain")

    def send_json(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_bytes(code, data, "application/json; charset=utf-8")

    def send_bytes(self, code, data, mime):
        self.send_response(code)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

def run():
    port = int(os.environ.get("PORT", "3033"))
    print(f"🎬 Moonveil Ep3 进度看板已就绪: http://localhost:{port}", flush=True)
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    server.serve_forever()

if __name__ == "__main__":
    run()
