import os,signal,subprocess,pathlib,json,time,re
P=pathlib.Path(__file__).resolve().parent;PROG=P/'proj/out/progress.json';NOTE=P/'benchmarks/six_worker_transition.json'
def processes():
 rows=[]
 for line in subprocess.run(['ps','-axo','pid=,ppid=,stat=,args='],capture_output=True,text=True).stdout.splitlines():
  f=line.strip().split(None,3)
  if len(f)==4:rows.append((int(f[0]),int(f[1]),f[2],f[3]))
 return rows
rows=processes();parents=[pid for pid,ppid,state,args in rows if args.endswith('Python -u render_parallel_ep3.py')]
if len(parents)!=1:raise RuntimeError('Cannot uniquely identify current queue')
parent=parents[0];os.kill(parent,signal.SIGSTOP)
d=json.loads(PROG.read_text());active=d['active_jobs'];children={pid:args for pid,ppid,state,args in processes() if ppid==parent and args.startswith('node ')}
note={'phase':'finishing_current_slices','parent':parent,'children':list(children),'started':time.time(),'active_keys':list(active)};NOTE.write_text(json.dumps(note,indent=2));print('WAITING FOR CURRENT SLICES',list(active),flush=True)
last={key:(-1,time.time()) for key in active}
while True:
 rows={pid:(state,args) for pid,ppid,state,args in processes()};running=[pid for pid in children if pid in rows and not rows[pid][0].startswith('Z')]
 if not running:break
 for key in active:
  log=P/'render_logs'/(key+'.log')
  if not log.exists():continue
  with log.open('rb') as f:f.seek(0,2);sz=f.tell();f.seek(max(0,sz-4096));s=f.read().decode(errors='replace')
  m=re.findall(r'Rendered (\d+)/',s);n=int(m[-1]) if m else -1;old,at=last[key]
  if n!=old:last[key]=(n,time.time())
  elif time.time()-at>180:
   for pid in running:
    if key+'.partial.mp4' in children[pid]:
     print('Retry stalled slice after transition',key,flush=True)
     try:os.killpg(pid,signal.SIGTERM)
     except ProcessLookupError:pass
   last[key]=(n,time.time())
 if time.time()-note['started']>600:
  os.kill(parent,signal.SIGCONT);note['phase']='cancelled_timeout';NOTE.write_text(json.dumps(note));raise SystemExit('Resumed original queue: transition timeout')
 time.sleep(2)
for key,v in active.items():
 a,b=map(int,v['frames'].split('-'));f=P/'proj/out/chunks'/(key+'.partial.mp4')
 if not f.exists():continue
 r=subprocess.run(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames','-of','json',str(f)],capture_output=True,text=True)
 try:valid=int(json.loads(r.stdout)['streams'][0]['nb_frames'])==b-a+1
 except Exception:valid=False
 if valid:f.replace(f.with_name(key+'.mp4'));print('PRESERVED',key,flush=True)
os.kill(parent,signal.SIGKILL)
note['phase']='six_workers_started';note['switched']=time.time();NOTE.write_text(json.dumps(note,indent=2));print('STARTING SIX WORKERS',flush=True)
env=os.environ.copy();env['JOBS']='6';env['CONC']='1'
fd=os.open(str(P/'render_optimized_six.log'),os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o644);os.dup2(fd,1);os.dup2(fd,2);os.close(fd);os.chdir(P)
os.execvpe('/usr/bin/caffeinate',['caffeinate','-i','python3','-u','render_parallel_ep3.py'],env)
