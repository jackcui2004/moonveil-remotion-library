#!/usr/bin/env python3
"""
Moonveil Ep3 — Mac M4 多切片多线程并行渲染器
基于 Ep2 稳定实战方案改造：
- 切片粒度：60 秒（1800 帧/切片）
- 默认并发：5 个并行切片任务（充分发挥 M4 10 核算力）
- 硬件加速：H.264 编码 + JPEG 90% 渲染流
- 健壮性：断点续跑、自动校验帧数、卡死超时自动重启重试
- 全自动化：全部切片渲染完成 -> 自动章节拼接 -> 自动总装混音出片 (Moonveil_Ep3_final.mp4)
"""
import concurrent.futures
import json
import os
import pathlib
import re
import signal
import subprocess
import sys
import threading
import time

# 确保 Homebrew 与系统工具路径在最前
os.environ["PATH"] = "/opt/homebrew/bin:/usr/local/bin:" + os.environ.get("PATH", "")

HERE = pathlib.Path(__file__).resolve().parent
PROJ = HERE / "proj"
OUT = PROJ / "out"
CH = OUT / "chunks"
LOG = HERE / "render_logs"

for d in (OUT, CH, LOG):
    d.mkdir(parents=True, exist_ok=True)

JOBS = int(os.environ.get("JOBS", "5"))
CONC = int(os.environ.get("CONC", "1"))
SLICE = int(os.environ.get("SLICE", "1800"))

REMOTION_BIN = PROJ / "node_modules" / ".bin" / "remotion"
if not REMOTION_BIN.exists():
    REMOTION_BIN = "remotion"
else:
    REMOTION_BIN = str(REMOTION_BIN)

FFPROBE = "/opt/homebrew/bin/ffprobe" if os.path.exists("/opt/homebrew/bin/ffprobe") else "ffprobe"
FFMPEG = "/opt/homebrew/bin/ffmpeg" if os.path.exists("/opt/homebrew/bin/ffmpeg") else "ffmpeg"

manifest_path = HERE / "manifest.json"
if not manifest_path.exists():
    print(f"错误: 未找到 {manifest_path}")
    sys.exit(1)

man = json.loads(manifest_path.read_text())
units = man["units"]
unit_frames = {u["id"]: u["frames"] for u in units}

def is_file_good(path, expected_frames):
    if not path.exists() or path.stat().st_size < 10000:
        return False
    cmd = [FFPROBE, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=nb_frames", "-of", "json", str(path)]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        data = json.loads(r.stdout)
        nb = int(data["streams"][0]["nb_frames"])
        return nb == expected_frames
    except Exception:
        return False

# 构建切片作业列表
jobs = []
unit_parts = {}
for u in units:
    uid = u["id"]
    total_f = u["frames"]
    unit_parts[uid] = []
    idx = 0
    for a in range(0, total_f, SLICE):
        b = min(a + SLICE, total_f) - 1
        dst = CH / f"{uid}_s{idx:03d}.mp4"
        unit_parts[uid].append(dst)
        jobs.append((uid, idx, a, b, dst))
        idx += 1

total_jobs = len(jobs)
total_frames = sum(u["frames"] for u in units)

lock = threading.Lock()
status = {
    "started": time.time(),
    "total_jobs": total_jobs,
    "completed_jobs": 0,
    "active_jobs": {},
    "failed_jobs": [],
    "jobs": JOBS,
    "concurrency_per_slice": CONC,
    "mode": "Chrome ANGLE / regular screenshots"
}

def save_progress():
    tmp = OUT / "progress.tmp"
    tmp.write_text(json.dumps(status, indent=2))
    tmp.replace(OUT / "progress.json")

def render_slice(job):
    uid, idx, a, b, dst = job
    key = dst.stem
    frames = b - a + 1
    
    # 检查是否已完成
    if is_file_good(dst, frames):
        with lock:
            status["completed_jobs"] += 1
            save_progress()
        print(f"⏩ [SKIP] {key} ({frames} 帧已完成)")
        return True

    partial = dst.with_name(dst.stem + ".partial.mp4")
    log_file = LOG / f"{key}.log"

    worker_idx = int(threading.current_thread().name.rsplit("_", 1)[-1])
    cmd = [
        REMOTION_BIN, "render", "src/index.ts", uid, str(partial),
        f"--frames={a}-{b}",
        f"--concurrency={CONC}",
        f"--port={6200 + worker_idx}",
        "--gl=angle",
        "--disable-shared-memory-capture",
        "--browser-executable=/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "--muted",
        "--codec=h264",
        "--crf=18",
        "--x264-preset=veryfast",
        "--image-format=jpeg",
        "--jpeg-quality=90",
        "--log=info",
        "--overwrite"
    ]

    for attempt in range(1, 4):
        with lock:
            status["active_jobs"][key] = {
                "start": time.time(),
                "frames": f"{a}-{b}",
                "attempt": attempt
            }
            save_progress()

        print(f"🎬 [START] {key} | 帧 {a}-{b} ({frames}f) | 尝试 #{attempt} | 总体: {status['completed_jobs']}/{total_jobs}", flush=True)

        with open(log_file, "w") as lf:
            proc = subprocess.Popen(cmd, cwd=str(PROJ), stdout=lf, stderr=subprocess.STDOUT, start_new_session=True)
            last_frame = -1
            last_change = time.time()

            while proc.poll() is None:
                time.sleep(2)
                # 检查日志尾部是否有进度
                try:
                    with open(log_file, "rb") as rf:
                        rf.seek(0, 2)
                        sz = rf.tell()
                        rf.seek(max(0, sz - 4096))
                        tail = rf.read().decode(errors="replace")
                    matches = re.findall(r"Rendered (\d+)/", tail)
                    if matches:
                        curr = int(matches[-1])
                        if curr != last_frame:
                            last_frame = curr
                            last_change = time.time()
                except Exception:
                    pass

                # 超时 150 秒无进度视为卡死，杀死并重试
                if time.time() - last_change > 150:
                    print(f"⚠️ [STALL] {key} 停滞在帧 {last_frame}，超时终止并重启...", flush=True)
                    try:
                        os.killpg(proc.pid, signal.SIGTERM)
                        proc.wait(timeout=10)
                    except Exception:
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.wait()
                    break

        if proc.returncode == 0 and is_file_good(partial, frames):
            partial.replace(dst)
            with lock:
                status["active_jobs"].pop(key, None)
                status["completed_jobs"] += 1
                save_progress()
            elapsed = time.time() - status["started"]
            rate = status["completed_jobs"] / max(elapsed, 1)
            rem_jobs = total_jobs - status["completed_jobs"]
            eta_min = (rem_jobs / rate) / 60 if rate > 0 else 0
            print(f"✅ [DONE] {key} | 耗时 {time.time()-last_change:.1f}s | 进度: {status['completed_jobs']}/{total_jobs} ({(status['completed_jobs']/total_jobs)*100:.1f}%) | 预计剩余: ~{eta_min:.1f} 分钟", flush=True)
            return True

        print(f"🔄 [RETRY] {key} 失败 (code {proc.returncode})，2 秒后重试...", flush=True)
        time.sleep(2)

    with lock:
        status["active_jobs"].pop(key, None)
        status["failed_jobs"].append(key)
        save_progress()
    print(f"❌ [FAILED] {key} 3 次尝试均失败！", flush=True)
    return False

def concat_files(file_list, dest_file):
    listing = OUT / f"{dest_file.stem}_concat.txt"
    listing.write_text("".join(f"file '{p.resolve()}'\n" for p in file_list))
    cmd = [FFMPEG, "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(listing), "-map", "0:v:0", "-c", "copy", str(dest_file)]
    subprocess.run(cmd, check=True)
    if listing.exists():
        listing.unlink()

def main():
    print(f"🚀 Moonveil Ep3 高速切片并行渲染已启动！")
    print(f"📊 总章节数: {len(units)} 章 | 总帧数: {total_frames} 帧 | 切片总数: {total_jobs} 个切片 (每切片 {SLICE} 帧/约 60s)")
    print(f"⚡️ 并行线程数: {JOBS} 进程并发 | 每切片渲染器: {CONC} 路 | Chrome ANGLE 绘制")
    print(f"📂 输出目录: {OUT}")
    print("=" * 60, flush=True)

    with concurrent.futures.ThreadPoolExecutor(max_workers=JOBS) as pool:
        results = list(pool.map(render_slice, jobs))

    if not all(results):
        print(f"❌ 部分切片渲染失败，请检查 {LOG}。重跑本脚本即可从断点继续。")
        sys.exit(1)

    print("\n" + "=" * 60)
    print("🎉 恭喜！全部切片已 100% 渲染完成！开始无损拼接 10 个章节单元...")
    print("=" * 60, flush=True)

    for i, u in enumerate(units, 1):
        uid = u["id"]
        total_f = u["frames"]
        unit_mp4 = OUT / f"{uid}.mp4"
        if is_file_good(unit_mp4, total_f):
            print(f"[{i}/{len(units)}] {uid}.mp4 已存在且校验通过，跳过拼接。")
            continue
        print(f"[{i}/{len(units)}] 正在拼接章节 {uid} ({len(unit_parts[uid])} 个切片)...", flush=True)
        concat_files(unit_parts[uid], unit_mp4)
        if not is_file_good(unit_mp4, total_f):
            print(f"❌ 警告: {uid}.mp4 拼接后帧数校验不符！")
            sys.exit(1)
        print(f"  ✓ {uid}.mp4 拼接完成并校验成功！")

    print("\n" + "=" * 60)
    print("🎬 10 个章节单元已全部准备就绪！开始执行总装脚本 (assemble_mac.sh)...")
    print("=" * 60, flush=True)

    r_asm = subprocess.run(["bash", str(HERE / "assemble_mac.sh")], cwd=str(HERE))
    if r_asm.returncode != 0:
        print("❌ 总装脚本执行失败，请检查上方日志。")
        sys.exit(1)

    print("\n" + "=" * 60)
    print("🏆 全集渲染与总装 100% 顺利完成！")
    final_mp4 = HERE / "Moonveil_Ep3_final.mp4"
    if final_mp4.exists():
        print(f"成片文件: {final_mp4} (大小: {final_mp4.stat().st_size / (1024*1024):.1f} MB)")
    print("=" * 60, flush=True)

if __name__ == "__main__":
    main()
