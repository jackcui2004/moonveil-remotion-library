import asyncio,pathlib,json,time,html,os,subprocess,edge_tts
P=pathlib.Path(__file__).resolve().parents[1];CACHE=P/'audio/tts_cache';ROWS=json.loads((P/'tts_manifest.json').read_text());N=int(os.environ.get('TTS_CONC','24'));sem=None
state={'stage':'tts','started':time.time(),'total_segments':len(ROWS),'complete_segments':0,'completed_seconds':0,'failed':[],'active':{}}
def save():
 tmp=P/'production_state.tmp';tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2));tmp.replace(P/'production_state.json')
def valid(row):
 f=CACHE/(row['cache_id']+'.json');a=CACHE/(row['cache_id']+'.mp3')
 if f.exists() and a.exists() and a.stat().st_size>1000:
  try:
   d=json.loads(f.read_text());return d if d['text']==row['text'] and d['duration']>0 and d['words'] else None
  except (ValueError,KeyError):pass
 return None
async def one(row):
 async with sem:
  old=valid(row)
  if old:
   state['complete_segments']+=1;state['completed_seconds']+=old['duration'];save();return old
  state['active'][row['id']]={'chapter':row['chapter'],'started':time.time()};save()
  for attempt in range(1,4):
   words=[];dst=CACHE/(row['cache_id']+'.mp3');partial=dst.with_suffix('.partial.mp3')
   try:
    c=edge_tts.Communicate(row['text'],voice='en-US-AvaMultilingualNeural',boundary='WordBoundary',connect_timeout=10,receive_timeout=60)
    with partial.open('wb') as f:
     async for e in c.stream():
      if e['type']=='audio':f.write(e['data'])
      elif e['type']=='WordBoundary':words.append({'text':html.unescape(e['text']),'start':e['offset']/1e7,'end':(e['offset']+e['duration'])/1e7})
    dur=float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(partial)],capture_output=True,text=True,check=True).stdout.strip())
    if not words or dur<.2 or partial.stat().st_size<1000:raise RuntimeError('Empty or invalid voice')
    if dur<row['words_expected']*.12:raise RuntimeError('Voice duration does not cover requested text')
    partial.replace(dst);result={**row,'voice':'en-US-AvaMultilingualNeural','duration':dur,'words':words,'audio':str(dst)};(CACHE/(row['cache_id']+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2));state['complete_segments']+=1;state['completed_seconds']+=dur;state['active'].pop(row['id'],None);save();print('VOICE',row['id'],round(dur,2),f"{state['complete_segments']}/{len(ROWS)}",flush=True);return result
   except Exception as e:
    print('VOICE_RETRY',row['id'],attempt,type(e).__name__,str(e),flush=True)
    if attempt<3:await asyncio.sleep(2*attempt)
    else:state['failed'].append({'id':row['id'],'error':str(e)});state['active'].pop(row['id'],None);save();return None
async def main():
 global sem
 sem=asyncio.Semaphore(N)
 save();result=await asyncio.gather(*(one(r) for r in ROWS));(P/'audio/tts_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));state['stage']='voice_ready' if all(result) else 'voice_failed';state['finished']=time.time();save()
 if not all(result):raise SystemExit('Some voice segments failed; inspect progress and rerun to resume')
 print('VOICE_ALL_READY',len(result),'seconds',round(state['completed_seconds'],2),flush=True)
asyncio.run(main())
