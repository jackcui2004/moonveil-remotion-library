import pathlib,json,subprocess,concurrent.futures,math
P=pathlib.Path(__file__).resolve().parents[1];D=json.loads((P/'src/episode_timeline.json').read_text());Q=P/'reports/frames';Q.mkdir(exist_ok=True)
cases=[]
for ch,mode,label in [(1,'video','hospital_motion'),(1,'diary','first_diary'),(8,'evidence','financial_evidence'),(9,'film','cafe_character'),(10,'video','final_stage')]:
 u=D['units'][ch-1];s=next(s for s in u['scenes'] if s['mode']==mode);t=min(s['end']-.1,s['start']+2.0);cases.append((u['id'],round(t*30),label))
def one(pair):
 i,(uid,f,label)=pair;cmd=['./node_modules/.bin/remotion','still','src/index.ts',uid,str(Q/(label+'.png')),f'--frame={f}',f'--port={6700+i}','--gl=angle','--browser-executable=/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--log=error']
 with (Q/(label+'.log')).open('w') as log:subprocess.run(cmd,cwd=P,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('FRAME_READY',label,uid,f,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(one,enumerate(cases)))
u=D['units'][0];s=next(s for s in u['scenes'] if s['mode']=='video');a=round(s['start']*30)+30
cmd=['./node_modules/.bin/remotion','render','src/index.ts',u['id'],str(Q/'motion_check.mp4'),f'--frames={a}-{a+59}','--concurrency=1','--port=6709','--gl=angle','--disable-shared-memory-capture','--browser-executable=/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--image-format=jpeg','--jpeg-quality=90','--codec=h264','--crf=18','--x264-preset=veryfast','--muted','--log=error']
with (Q/'motion_check.log').open('w') as log:subprocess.run(cmd,cwd=P,stdout=log,stderr=subprocess.STDOUT,check=True)
print('MOTION_READY',flush=True)
