import pathlib,json,subprocess,wave,math,re,bisect,difflib,shutil,time
from director_plan import PLAN
P=pathlib.Path(__file__).resolve().parents[1];A=P/'audio';PUB=P/'public';RATE=48000;FPS=30
rows=json.loads((A/'tts_results.json').read_text());assert len(rows)==396 and all(rows)
chapters=json.loads((P/'chapters_source.json').read_text());state=json.loads((P/'production_state.json').read_text());state['stage']='building_audio';state['audio_chapter']=0

def save():
 t=P/'production_state.tmp';t.write_text(json.dumps(state,ensure_ascii=False,indent=2));t.replace(P/'production_state.json')
def setup(w):w.setnchannels(1);w.setsampwidth(2);w.setframerate(RATE)
def tokens(s):return re.findall('[a-z0-9]+',s.lower())
units=[];global_frames=0;coverage=[]
with wave.open(str(A/'voice_full.wav'),'wb') as full:
 setup(full)
 for c in chapters:
  idx=c['chapter'];local=0.;words=[];segments=[];chapter_pcm=[]
  # Each successful TTS file is decoded and measured; no file-count-only acceptance.
  for row in [r for r in rows if r['chapter']==idx]:
   pcm=subprocess.run(['ffmpeg','-v','error','-i',row['audio'],'-ar',str(RATE),'-ac','1','-f','s16le','-'],capture_output=True,check=True).stdout
   seconds=len(pcm)/2/RATE;gap=.35 if row['kind']=='title' else .12
   local_words=[{'text':w['text'],'start':round(local+w['start'],6),'end':round(local+min(w['end'],seconds),6)} for w in row['words']]
   segments.append({'id':row['id'],'kind':row['kind'],'text':row['text'],'start':local,'end':local+seconds,'words':local_words})
   if row['kind']=='body':words.extend(local_words)
   chapter_pcm.extend([pcm,bytes(round(gap*RATE)*2)]);local+=seconds+gap
  chapter_pcm.append(bytes(round(.45*RATE)*2));local+=.45
  frames=math.ceil(local*FPS);dur=frames/FPS;current=sum(len(b) for b in chapter_pcm)//2;chapter_pcm.append(bytes(max(0,round(dur*RATE)-current)*2))
  path=A/f'chapter_{idx:02d}.wav'
  with wave.open(str(path),'wb') as out:
   setup(out)
   for b in chapter_pcm:out.writeframesraw(b);full.writeframesraw(b)
  title_end=next(s['start'] for s in segments if s['kind']=='body')
  # Locate each hand-planned cue in original text, then map it to actual voice tokens.
  source=[];source_rows=[];voice_tokens=[];voice_times=[]
  for seg in [s for s in segments if s['kind']=='body']:
   raw=tokens(seg['text']);heard=[];heard_times=[]
   for w in seg['words']:
    for tok in tokens(w['text']):heard.append(tok);heard_times.append((w['start'],w['end']))
   matcher=difflib.SequenceMatcher(None,raw,heard,autojunk=False);mapping={}
   for block in matcher.get_matching_blocks():
    for k in range(block.size):mapping[block.a+k]=heard_times[block.b+k]
   ratio=len(mapping)/max(1,len(raw));coverage.append({'segment':seg['id'],'exact_token_ratio':ratio})
   for k,tok in enumerate(raw):
    at=mapping.get(k)
    if at is None:
     before=max((j for j in mapping if j<k),default=None);after=min((j for j in mapping if j>k),default=None)
     if before is not None and after is not None:
      z=(k-before)/(after-before);a=mapping[before][1]+z*(mapping[after][0]-mapping[before][1]);at=(a,a+.08)
     else:at=(seg['start']+k/max(1,len(raw))*(seg['end']-seg['start']),seg['start']+(k+1)/max(1,len(raw))*(seg['end']-seg['start']))
    source.append(tok);voice_times.append(at);source_rows.append(seg['text'])
  cursor=0;beats=[]
  for b in PLAN[idx]:
   q=tokens(b['cue']);loc=next((i for i in range(cursor,len(source)-len(q)+1) if source[i:i+len(q)]==q),None)
   if loc is None:raise ValueError(f'Unmapped cue CH{idx}: {b["cue"]}')
   cursor=loc;quote=b.get('quote') or ' '.join(source_rows[loc].split()[:26]).strip('"')
   if len(source_rows[loc].split())>26 and not b.get('quote'):quote+='…'
   beats.append({**b,'start':max(title_end,voice_times[loc][0]),'quote':quote})
  if beats:beats[0]['start']=title_end
  for i in range(len(beats)-1):
   if beats[i]['mode']=='video':beats[i+1]['start']=max(beats[i+1]['start'],beats[i]['start']+10)
  scenes=[]
  def add_parts(b,start,end,asset,mode):
   if end-start<.08:return
   count=max(1,math.ceil((end-start)/21));starts=[start]
   for j in range(1,count):
    target=start+j*(end-start)/count;options=[w['start'] for w in words if abs(w['start']-target)<1]
    starts.append(min(options,key=lambda x:abs(x-target)) if options else target)
   starts.append(end)
   for j,(a,z) in enumerate(zip(starts,starts[1:])):
    actual=mode
    if j>0 and mode=='film':actual=['detail','diary','film'][(j-1)%3]
    elif j>0 and mode in ['quote','diary','evidence']:actual=mode if j%2==0 else 'detail'
    scenes.append({'start':round(a,5),'end':round(z,5),'asset':'v17/'+asset,'mode':actual,'title':b['title'],'quote':b['quote'],'cue':b['cue'],'variant':j,'video_scale':b.get('video_scale',1),'video_origin':b.get('video_origin','50% 50%')})
  for i,b in enumerate(beats):
   end=beats[i+1]['start'] if i+1<len(beats) else dur
   if b['mode']=='video':
    z=min(end,b['start']+10);add_parts(b,b['start'],z,b['asset'],'video');add_parts(b,z,end,b.get('follow',b['asset'].replace('.mp4','.png')),'film')
   else:add_parts(b,b['start'],end,b['asset'],b['mode'])
  captions=[]
  for seg in segments:
   if seg['kind']=='title':continue
   groups=[];group=[]
   for w in seg['words']:
    group.append(w)
    if len(group)>=11 or (len(group)>=5 and re.search('[,.;!?]$',w['text'])):groups.append(group);group=[]
   if group:groups.append(group)
   for j,g in enumerate(groups):
    end=groups[j+1][0]['start'] if j+1<len(groups) else min(dur,g[-1]['end']+.2)
    captions.append({'start':g[0]['start'],'end':max(end,g[0]['start']+.02),'words':g,'text':' '.join(w['text'] for w in g)})
  unit={'id':f'unit-ep4-ch{idx:02d}','chapter':idx,'title':c['title'].split(':',1)[1].strip(),'start':global_frames/FPS,'end':(global_frames+frames)/FPS,'frames':frames,'duration':dur,'title_end':title_end,'source_words':c['words'],'captions':captions,'scenes':scenes}
  units.append(unit);global_frames+=frames;state['audio_chapter']=idx;save();print('CHAPTER_BUILT',idx,'seconds',round(dur,2),'visual_shots',len(scenes),'captions',len(captions),flush=True)
# Copy actual video-derived stills; these are extracted source frames, not newly generated art.
inspection=P.parent/'EP4_v17_素材/inspection';(PUB/'v17/posters').mkdir(exist_ok=True)
for f in inspection.glob('*.png'):shutil.copy2(f,PUB/'v17/posters'/f.name)
missing=sorted({s['asset'] for u in units for s in u['scenes'] if not (PUB/s['asset']).is_file()})
if missing:raise ValueError('Missing mapped assets: '+str(missing))
timeline={'fps':FPS,'width':1920,'height':1080,'audio':'full_audio.m4a','scope':'full-episode','units':units};(P/'src/episode_timeline.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2));(P/'manifest.json').write_text(json.dumps({'episode':'EP4 v17 Noir / Diary','fps':FPS,'units':[{'id':u['id'],'frames':u['frames']} for u in units]},indent=2))
(P/'reports/alignment_report.json').write_text(json.dumps({'segments':len(rows),'body_words':sum(c['words'] for c in chapters),'coverage':coverage,'minimum_exact_token_ratio':min(x['exact_token_ratio'] for x in coverage),'mean_exact_token_ratio':sum(x['exact_token_ratio'] for x in coverage)/len(coverage)},indent=2))
# Sparse structural sounds only. No popup, bong, low impact, bell, music bed, or person-change whoosh.
cmd=['ffmpeg','-y','-v','error','-i',str(A/'voice_full.wav')];fs=['[0:a]anull[v]'];labels=['[v]'];events=[]
for i,u in enumerate(units):
 at=u['start']+.08;cmd+=['-i',str(PUB/'sfx/air_swish.wav')];fs.append(f'[{i+1}:a]volume=0.018,adelay={round(at*1000)}:all=1[s{i}]');labels.append(f'[s{i}]');events.append({'at':at,'asset':'air_swish.wav','gain':.018,'reason':'chapter structure only'})
fs.append(''.join(labels)+f'amix=inputs={len(labels)}:duration=first:normalize=0,alimiter=limit=0.94:level=false:latency=true[mix]')
raw=A/'full_mix_raw.wav';subprocess.run(cmd+['-filter_complex',';'.join(fs),'-map','[mix]','-c:a','pcm_s16le',str(raw)],check=True)
state['stage']='normalizing_audio';save();r=subprocess.run(['ffmpeg','-hide_banner','-i',str(raw),'-af','loudnorm=I=-18.6:TP=-0.5:LRA=11:print_format=json','-f','null','-'],capture_output=True,text=True,check=True);m=json.JSONDecoder().raw_decode(r.stderr[r.stderr.rfind('{'):])[0]
filt='loudnorm=I=-18.6:TP=-0.5:LRA=11:measured_I='+m['input_i']+':measured_TP='+m['input_tp']+':measured_LRA='+m['input_lra']+':measured_thresh='+m['input_thresh']+':offset='+m['target_offset']+':linear=true'
subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af',filt,'-ar','48000','-ac','1','-c:a','aac','-b:a','160k','-movflags','+faststart',str(PUB/'full_audio.m4a')],check=True)
(P/'reports/audio_mix.json').write_text(json.dumps({'low_impact_dong_events':0,'popup_events':0,'music_bed':False,'events':events,'loudness_measurement':m},indent=2));state.update(stage='timeline_ready',total_frames=global_frames,total_seconds=global_frames/FPS,visual_shots=sum(len(u['scenes']) for u in units));save();print('FULL_TIMELINE_READY',global_frames,'frames',round(global_frames/FPS,2),'seconds',flush=True)
