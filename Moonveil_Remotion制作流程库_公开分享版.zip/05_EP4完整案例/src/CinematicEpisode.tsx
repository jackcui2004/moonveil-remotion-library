import React from 'react';
import {AbsoluteFill,Img,Html5Audio,Html5Video,OffthreadVideo,Sequence,interpolate,staticFile,useCurrentFrame,getRemotionEnvironment} from 'remotion';
import timeline from './episode_timeline.json';
const FPS=30;const C={ink:'#101114',paper:'#e8dfcc',gold:'#c9ad77',white:'#f4f0e7',red:'#95433d'};
const SERIF='Baskerville, "Times New Roman", serif';const SANS='"Helvetica Neue", Arial, sans-serif';const SCRIPT='"Snell Roundhand", "Apple Chancery", cursive';
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const norm=(s:string)=>s.replace(/^[“”"']|[“”"']$/g,'');
function poster(asset:string){return asset.endsWith('.mp4')?`v17/posters/${asset.split('/').pop()!.replace('.mp4','')}_1.png`:asset;}
const portraitNames=['heroine/','ch05-frank','ch05-gloria','ch07-helen','ch09-mia'];
const Backdrop:React.FC<{s:any,t:number,frozen?:boolean}>=({s,t,frozen=false})=>{
 const f=useCurrentFrame();const isPortrait=portraitNames.some(x=>s.asset.includes(x));const isVideo=s.mode==='video'&&!frozen&&t>=s.start;const Video=getRemotionEnvironment().isRendering?OffthreadVideo:Html5Video;
 const life=Math.max(.001,s.end-s.start);const z=interpolate(t,[s.start,s.end],[1.01,s.mode==='detail'?1.13:1.045],clamp);const origin=isPortrait?'50% 28%':'50% 45%';
 const style:React.CSSProperties={position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover',objectPosition:isPortrait?'50% 28%':'50% 45%',transform:isVideo?`scale(${s.video_scale??1})`:`scale(${z})`,transformOrigin:isVideo?(s.video_origin??origin):origin,filter:'saturate(.72) contrast(1.04) brightness(.86)'};
 return <AbsoluteFill style={{top:76,bottom:140,height:'auto',overflow:'hidden'}}>
  <Img src={staticFile(frozen&&s.asset.endsWith('.mp4')?poster(s.asset).replace('_1.png','_2.png'):poster(s.asset))} style={style}/>
  {isVideo&&<div style={{position:'absolute',inset:0}}><Sequence from={Math.round(s.start*FPS)} durationInFrames={Math.min(300,Math.max(1,Math.round(life*FPS)))} layout="none"><div style={{position:'absolute',inset:0}}><Video src={staticFile(s.asset)} muted style={style}/></div></Sequence></div>}
  <AbsoluteFill style={{background:'linear-gradient(90deg,#070c1380,transparent 50%,#070c1340),linear-gradient(0deg,#0a0d12d9,transparent 65%)'}}/>
 </AbsoluteFill>;
};
const Micro:React.FC<{children:React.ReactNode,style?:React.CSSProperties}>=({children,style})=><div style={{fontFamily:SANS,fontSize:17,letterSpacing:3,fontWeight:500,...style}}>{children}</div>;
const Diary:React.FC<{s:any,t:number}>=({s,t})=>{
 const text=norm(s.quote);const title=s.title;const fs=title.length>34?40:title.length>19?54:72;const qfs=text.split(' ').length>18?43:text.split(' ').length>11?52:64;const lines=Math.ceil(title.length*fs*.52/780);const top=Math.max(310,155+lines*fs*1.05+45);
 return <AbsoluteFill style={{top:76,bottom:140,height:'auto',background:C.paper,color:'#28251f',overflow:'hidden'}}>
  <AbsoluteFill style={{background:'repeating-linear-gradient(0deg,transparent 0,transparent 45px,#5b472a0a 46px,transparent 47px),radial-gradient(ellipse at 20% 40%,#f1e8d5,transparent 70%)'}}/>
  <div style={{position:'absolute',left:980,top:0,bottom:0,width:42,background:'linear-gradient(90deg,transparent,#56442d24,transparent)'}}/>
  <Micro style={{position:'absolute',left:105,top:66,color:'#88714f',fontSize:15}}>FROM MY JOURNAL / NEW YORK</Micro>
  <div style={{position:'absolute',left:104,top:151,width:800,fontFamily:SERIF,fontSize:fs,lineHeight:1.06,fontStyle:'italic'}}>{title}</div>
  <div style={{position:'absolute',left:110,top,width:795,fontFamily:SERIF,fontSize:qfs,lineHeight:1.25,color:'#4e4231'}}>{text}</div>
  <div style={{position:'absolute',left:111,top:740,width:200,height:2,background:'#9c7a4f70'}}/>
  <div style={{position:'absolute',left:1084,top:64,width:652,height:708,boxSizing:'border-box',padding:20,paddingBottom:70,background:'#f8f3e6',boxShadow:'4px 12px 22px #3a2c242c',transform:'rotate(1.5deg)'}}>
   <Img src={staticFile(poster(s.asset))} style={{width:'100%',height:'100%',objectFit:'cover',objectPosition:portraitNames.some(x=>s.asset.includes(x))?'50% 27%':'42% 45%',filter:'saturate(.65) sepia(.12)'}}/>
   <div style={{position:'absolute',left:26,bottom:16,fontFamily:SCRIPT,fontSize:28,color:'#5c503c'}}>The things I remember.</div>
  </div>
 </AbsoluteFill>;
};
const Evidence:React.FC<{s:any,t:number}>=({s,t})=>{
 const title=s.title;const size=title.length>46?50:title.length>27?66:title.length>15?86:112;return <AbsoluteFill style={{top:76,bottom:140,height:'auto',overflow:'hidden',background:'#111519'}}>
  <div style={{position:'absolute',left:76,top:60,width:690,height:680,overflow:'hidden',border:'1px solid #baa37555'}}><Img src={staticFile(poster(s.asset))} style={{width:'100%',height:'100%',objectFit:'cover',objectPosition:'50% 35%',filter:'saturate(.35) brightness(.66)'}}/></div>
  <div style={{position:'absolute',left:842,right:102,top:140}}><Micro style={{fontSize:15,color:'#a5a8aa'}}>CASE FILE / PERSONAL RECORD</Micro><div style={{width:60,height:2,background:C.red,marginTop:28,marginBottom:32}}/>
   <div style={{fontFamily:SERIF,fontSize:size,lineHeight:1.04,color:C.gold,overflowWrap:'anywhere'}}>{title}</div>
   <div style={{fontFamily:SERIF,fontStyle:'italic',fontSize:34,lineHeight:1.3,marginTop:36,color:'#d5d0c6'}}>{norm(s.quote).split(' ').slice(0,20).join(' ')}</div>
  </div>
 </AbsoluteFill>;
};
function Subtitles({u,t}:{u:any,t:number}){
 const c=u.captions.find((x:any)=>t>=x.start&&t<x.end);if(!c)return null;
 return <div style={{position:'absolute',left:130,right:130,bottom:25,zIndex:60,display:'flex',justifyContent:'center'}}><div style={{maxWidth:1540,fontFamily:SANS,fontSize:35,lineHeight:1.34,fontWeight:500,textAlign:'center',color:C.white,textShadow:'0 2px 5px #000'}}>{c.words.map((w:any,i:number)=><span key={i} style={{color:t>=w.start&&t<w.end?C.gold:C.white,marginRight:9,borderBottom:t>=w.start&&t<w.end?'2px solid '+C.gold:'2px solid transparent'}}>{w.text}</span>)}</div></div>;
}
export const CinematicEpisode:React.FC<{unitId:string}>=({unitId})=>{
 const frame=useCurrentFrame();const t=frame/FPS;const u=timeline.units.find(u=>u.id===unitId)!;let idx=u.scenes.findIndex(s=>t>=s.start&&t<s.end);if(idx<0)idx=t<u.title_end?0:u.scenes.length-1;const s=u.scenes[idx];const previous=idx>0?u.scenes[idx-1]:null;
 const transition=interpolate(t,[s.start,s.start+.22],[0,1],clamp);const titleOut=interpolate(t,[u.title_end-.35,u.title_end],[1,0],clamp);const isLast=u.chapter===10;const fade=isLast?interpolate(t,[u.duration-.5,u.duration],[1,0],clamp):1;
 function scene(node:any,frozen=false){if(node.mode==='diary')return <Diary s={node} t={t}/>;if(node.mode==='evidence')return <Evidence s={node} t={t}/>;return <><Backdrop s={node} t={t} frozen={frozen||t<u.title_end}/>{node.mode==='quote'&&<div style={{position:'absolute',inset:0,background:'#05080b80',top:76,bottom:140,height:'auto',display:'flex',alignItems:'center',padding:'0 135px'}}><div style={{maxWidth:1490}}><Micro style={{color:C.gold,fontSize:16,marginBottom:25}}>{node.title}</Micro><div style={{fontFamily:SERIF,fontStyle:'italic',fontSize:node.quote.split(' ').length>19?62:84,lineHeight:1.12,color:C.white}}>{norm(node.quote)}</div></div></div>}</>;}
 return <AbsoluteFill style={{background:C.ink,color:C.white,opacity:fade,overflow:'hidden'}}>
  {!getRemotionEnvironment().isRendering&&<Html5Audio src={staticFile(timeline.audio)} startFrom={Math.round(u.start*FPS)} endAt={Math.round(u.end*FPS)}/>}
  {previous&&transition<1&&scene(previous,true)}<AbsoluteFill style={{opacity:previous?transition:1}}>{scene(s)}</AbsoluteFill>
  <div style={{position:'absolute',left:0,right:0,top:0,height:76,background:'#0c0d0f',borderBottom:'1px solid #bca77c25',display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 72px',zIndex:50}}><Micro style={{color:C.gold,fontSize:17,letterSpacing:5}}>MOONVEIL STORIES</Micro><Micro style={{fontSize:15,color:'#b6b6b0',letterSpacing:2,textAlign:'right',maxWidth:1200}}>{String(u.chapter).padStart(2,'0')} / {u.title.toUpperCase()}</Micro></div>
  <div style={{position:'absolute',bottom:0,left:0,right:0,height:140,background:'#0c0d0f',borderTop:'1px solid #bca77c20',zIndex:40}}/>
  {titleOut>0&&<AbsoluteFill style={{top:76,bottom:140,height:'auto',background:'linear-gradient(90deg,#070b10e8,#070b1080)',opacity:titleOut,zIndex:30}}><div style={{position:'absolute',left:110,top:250,right:140}}><Micro style={{color:C.gold,marginBottom:28}}>CHAPTER {u.chapter}</Micro><div style={{fontFamily:SERIF,fontSize:u.title.length>45?86:108,lineHeight:1.02,fontStyle:'italic',maxWidth:1500}}>{u.title}</div><div style={{height:2,width:180,background:C.gold,marginTop:40}}/></div></AbsoluteFill>}
  <Subtitles u={u} t={t}/><div style={{position:'absolute',left:0,bottom:139,height:2,width:1920*Math.min(1,t/u.duration),background:C.gold,zIndex:55,opacity:.45}}/>
 </AbsoluteFill>;
};
