import React from 'react';
import {Composition} from 'remotion';
import {CinematicEpisode} from './CinematicEpisode';
import data from './episode_timeline.json';
export const Root:React.FC=()=> <>{data.units.map(u=><Composition key={u.id} id={u.id} component={CinematicEpisode} durationInFrames={u.frames} fps={data.fps} width={data.width} height={data.height} defaultProps={{unitId:u.id}}/>)}</>;
